const router = require('express').Router();
const {
  listDeals, getDeal, createDeal, updateDeal,
  updateDealStatus, toggleStar, deleteDeal,
  getStats, getStatusCategories,
} = require('../controllers/deals.controller');
const { optionalAuth, authenticate } = require('../middlewares/auth');
const {
  createDealRules, updateDealRules, updateStatusRules,
  listDealsRules, validate,
} = require('../validators/deals.validator');

// Public in Phase 1 (add authenticate middleware in Phase 2 for multi-tenant)
// Using optionalAuth so org_id from JWT is used when token present,
// falling back to DEFAULT_ORG_ID otherwise

// GET /api/v1/deals/stats
router.get('/stats', optionalAuth, getStats);

// GET /api/v1/deals/status-categories
router.get('/status-categories', optionalAuth, getStatusCategories);

// GET /api/v1/deals
router.get('/', optionalAuth, listDealsRules, validate, listDeals);

// GET /api/v1/deals/:id
router.get('/:id', optionalAuth, getDeal);

// POST /api/v1/deals
router.post('/', optionalAuth, createDealRules, validate, createDeal);

// PUT /api/v1/deals/:id
router.put('/:id', optionalAuth, updateDealRules, validate, updateDeal);

// PATCH /api/v1/deals/:id/status
router.patch('/:id/status', optionalAuth, updateStatusRules, validate, updateDealStatus);

// PATCH /api/v1/deals/:id/star
router.patch('/:id/star', optionalAuth, toggleStar);

// DELETE /api/v1/deals/:id
router.delete('/:id', optionalAuth, deleteDeal);

module.exports = router;
