const router = require('express').Router();
const {
  listStatements, getLatest, getById, getNOI, createStatement,
} = require('../controllers/operatingStatement.controller');
const { optionalAuth } = require('../middlewares/auth');

// GET  /api/v1/deals/:dealId/operating-statement
router.get('/:dealId/operating-statement', optionalAuth, listStatements);

// GET  /api/v1/deals/:dealId/operating-statement/latest
router.get('/:dealId/operating-statement/latest', optionalAuth, getLatest);

// GET  /api/v1/deals/:dealId/operating-statement/noi-summary
router.get('/:dealId/operating-statement/noi-summary', optionalAuth, getNOI);

// GET  /api/v1/deals/:dealId/operating-statement/:osId
router.get('/:dealId/operating-statement/:osId', optionalAuth, getById);

// POST /api/v1/deals/:dealId/operating-statement
router.post('/:dealId/operating-statement', optionalAuth, createStatement);

module.exports = router;
