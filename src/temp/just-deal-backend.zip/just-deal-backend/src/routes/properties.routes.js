const router = require('express').Router();
const { getProperty, upsertProperty } = require('../controllers/properties.controller');
const { optionalAuth } = require('../middlewares/auth');

// GET  /api/v1/deals/:dealId/property
router.get('/:dealId/property', optionalAuth, getProperty);

// PUT  /api/v1/deals/:dealId/property
router.put('/:dealId/property', optionalAuth, upsertProperty);

module.exports = router;
