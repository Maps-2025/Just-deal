const router = require('express').Router();
const { register, login, getMe } = require('../controllers/auth.controller');
const { authenticate } = require('../middlewares/auth');
const { loginRules, registerRules, validate } = require('../validators/auth.validator');

// POST /api/v1/auth/register
router.post('/register', registerRules, validate, register);

// POST /api/v1/auth/login
router.post('/login', loginRules, validate, login);

// GET /api/v1/auth/me  (protected)
router.get('/me', authenticate, getMe);

module.exports = router;
