const router = require('express').Router();
const { listUsers, getUser } = require('../controllers/users.controller');
const { authenticate } = require('../middlewares/auth');

// GET /api/v1/users
router.get('/', authenticate, listUsers);

// GET /api/v1/users/:id
router.get('/:id', authenticate, getUser);

module.exports = router;
