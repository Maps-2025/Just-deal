const router = require('express').Router();
const {
  listRentRolls, getLatest, getUnits, getUnitMix, createRentRoll,
} = require('../controllers/rentRoll.controller');
const { optionalAuth } = require('../middlewares/auth');

// GET  /api/v1/deals/:dealId/rent-roll
router.get('/:dealId/rent-roll', optionalAuth, listRentRolls);

// GET  /api/v1/deals/:dealId/rent-roll/latest
router.get('/:dealId/rent-roll/latest', optionalAuth, getLatest);

// GET  /api/v1/deals/:dealId/rent-roll/units
router.get('/:dealId/rent-roll/units', optionalAuth, getUnits);

// GET  /api/v1/deals/:dealId/rent-roll/unit-mix
router.get('/:dealId/rent-roll/unit-mix', optionalAuth, getUnitMix);

// POST /api/v1/deals/:dealId/rent-roll
router.post('/:dealId/rent-roll', optionalAuth, createRentRoll);

module.exports = router;
