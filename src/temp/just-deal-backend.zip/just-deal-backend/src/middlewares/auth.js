const jwt = require('jsonwebtoken');
const jwtConfig = require('../config/jwt');
const AppError = require('../utils/AppError');
const { prisma } = require('../config/database');

async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next(AppError.unauthorized('No token provided'));
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, jwtConfig.secret);

    const user = await prisma.user.findUnique({ where: { id: decoded.sub } });
    if (!user) return next(AppError.unauthorized('User not found'));

    req.user = {
      id: user.id,
      email: user.email,
      name: user.name,
      org_id: decoded.org_id,
      role: decoded.role,
    };

    next();
  } catch (err) {
    next(err);
  }
}

// Optional auth — attaches user if token present, continues either way
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, jwtConfig.secret);
      req.user = {
        id: decoded.sub,
        email: decoded.email,
        org_id: decoded.org_id,
        role: decoded.role,
      };
    }
  } catch (_) {
    // ignore — continue without user
  }
  next();
}

module.exports = { authenticate, optionalAuth };
