const logger = require('../utils/logger');

function requestLogger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - start;
    const color = res.statusCode >= 400 ? '\x1b[31m' : '\x1b[32m';
    logger.http(`${req.method} ${req.url} ${color}${res.statusCode}\x1b[0m — ${ms}ms`);
  });
  next();
}

module.exports = { requestLogger };
