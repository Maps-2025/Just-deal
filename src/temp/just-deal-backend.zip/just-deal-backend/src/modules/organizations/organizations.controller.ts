import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { PrismaService } from '../../database/prisma.service';

@ApiTags('organizations')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('organizations')
export class OrganizationsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get(':id/members')
  @ApiOperation({ summary: 'List all members of an organization' })
  getMembers(@Param('id') id: string) {
    return this.prisma.orgMembership.findMany({
      where: { organization_id: id },
      include: {
        user: { select: { id: true, email: true, name: true } },
      },
    });
  }
}
