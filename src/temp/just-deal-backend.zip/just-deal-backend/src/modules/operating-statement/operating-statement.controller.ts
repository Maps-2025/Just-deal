import { Controller, Get, Post, Param, Query, Body } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { OperatingStatementService } from './operating-statement.service';
import { GetOsQueryDto, CreateOperatingStatementDto } from './dto/operating-statement.dto';

@ApiTags('operating-statement')
@ApiBearerAuth()
@Controller('deals/:dealId/operating-statement')
export class OperatingStatementController {
  constructor(private readonly osService: OperatingStatementService) {}

  @Get()
  @ApiOperation({ summary: 'List all operating statements for a deal' })
  findAll(@Param('dealId') dealId: string, @Query() query: GetOsQueryDto) {
    return this.osService.findAllByDeal(dealId, query);
  }

  @Get('latest')
  @ApiOperation({ summary: 'Get latest operating statement with line items' })
  findLatest(@Param('dealId') dealId: string, @Query('budget_type') budgetType?: string) {
    return this.osService.findLatest(dealId, budgetType);
  }

  @Get('noi-summary')
  @ApiOperation({ summary: 'Get NOI summary (EGI, Expenses, NOI, Expense Ratio)' })
  getNOI(@Param('dealId') dealId: string) {
    return this.osService.getNOISummary(dealId);
  }

  @Get(':osId')
  @ApiOperation({ summary: 'Get a specific operating statement with all line items' })
  findOne(@Param('osId') osId: string) {
    return this.osService.findOne(osId);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new operating statement header (for future upload)' })
  create(@Param('dealId') dealId: string, @Body() dto: CreateOperatingStatementDto) {
    return this.osService.create(dealId, dto);
  }
}
