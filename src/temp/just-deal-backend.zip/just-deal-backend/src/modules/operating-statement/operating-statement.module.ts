import { Module } from '@nestjs/common';
import { OperatingStatementController } from './operating-statement.controller';
import { OperatingStatementService } from './operating-statement.service';
import { OperatingStatementRepository } from './operating-statement.repository';

@Module({
  controllers: [OperatingStatementController],
  providers: [OperatingStatementService, OperatingStatementRepository],
  exports: [OperatingStatementService],
})
export class OperatingStatementModule {}
