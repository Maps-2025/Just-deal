import { IsDateString, IsIn, IsOptional, IsBoolean, IsNumber, IsString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export const PERIOD_TYPES = ['Monthly', 'Annual'] as const;
export const BUDGET_TYPES = ['Actuals', 'Proforma 1', 'Proforma 2', 'Proforma 3'] as const;

export class GetOsQueryDto {
  @ApiPropertyOptional({ enum: BUDGET_TYPES })
  @IsOptional()
  @IsIn(BUDGET_TYPES)
  budget_type?: string;

  @ApiPropertyOptional({ enum: PERIOD_TYPES })
  @IsOptional()
  @IsIn(PERIOD_TYPES)
  period_type?: string;
}

export class CreateOperatingStatementDto {
  @ApiProperty() @IsDateString() period_start: string;
  @ApiProperty() @IsDateString() period_end: string;
  @ApiProperty({ enum: PERIOD_TYPES }) @IsIn(PERIOD_TYPES) period_type: string;
  @ApiProperty({ enum: BUDGET_TYPES }) @IsIn(BUDGET_TYPES) budget_type: string;
}
