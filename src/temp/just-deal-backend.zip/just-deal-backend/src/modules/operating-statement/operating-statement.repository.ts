// ─── operating-statement.repository.ts ───────────────────────────────────────
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../database/prisma.service';
import { GetOsQueryDto, CreateOperatingStatementDto } from './dto/operating-statement.dto';

@Injectable()
export class OperatingStatementRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findAllByDeal(dealPk: string, query: GetOsQueryDto) {
    return this.prisma.operatingStatement.findMany({
      where: {
        deal_pk: dealPk,
        ...(query.budget_type && { budget_type: query.budget_type }),
        ...(query.period_type && { period_type: query.period_type }),
      },
      orderBy: { uploaded_at: 'desc' },
      select: {
        id: true,
        period_start: true,
        period_end: true,
        period_type: true,
        budget_type: true,
        uploaded_at: true,
      },
    });
  }

  async findWithLineItems(osId: string) {
    return this.prisma.operatingStatement.findUnique({
      where: { id: osId },
      include: {
        line_items: { orderBy: [{ is_income: 'desc' }, { account_code: 'asc' }] },
      },
    });
  }

  async findLatestByDeal(dealPk: string, budgetType = 'Actuals') {
    return this.prisma.operatingStatement.findFirst({
      where: { deal_pk: dealPk, budget_type: budgetType },
      orderBy: { period_end: 'desc' },
      include: {
        line_items: { orderBy: [{ is_income: 'desc' }, { account_code: 'asc' }] },
      },
    });
  }

  // Compute NOI summary from line items
  async getNOISummary(dealPk: string) {
    const os = await this.findLatestByDeal(dealPk, 'Actuals');
    if (!os) return null;

    const income = os.line_items
      .filter((l) => l.is_income)
      .reduce((sum, l) => sum + Number(l.amount), 0);

    const expenses = os.line_items
      .filter((l) => !l.is_income)
      .reduce((sum, l) => sum + Number(l.amount), 0);

    return {
      os_id: os.id,
      period: `${os.period_start.toISOString().slice(0, 7)} – ${os.period_end.toISOString().slice(0, 7)}`,
      budget_type: os.budget_type,
      effective_gross_income: Math.round(income),
      total_expenses: Math.round(expenses),
      noi: Math.round(income - expenses),
      expense_ratio: income > 0 ? Math.round((expenses / income) * 1000) / 10 : 0,
    };
  }

  async create(dealPk: string, dto: CreateOperatingStatementDto, userId?: string) {
    return this.prisma.operatingStatement.create({
      data: {
        deal_pk: dealPk,
        period_start: new Date(dto.period_start),
        period_end: new Date(dto.period_end),
        period_type: dto.period_type,
        budget_type: dto.budget_type,
        uploaded_by_user_id: userId,
      },
    });
  }
}
