import { Injectable, NotFoundException } from '@nestjs/common';
import { OperatingStatementRepository } from './operating-statement.repository';
import { GetOsQueryDto, CreateOperatingStatementDto } from './dto/operating-statement.dto';

@Injectable()
export class OperatingStatementService {
  constructor(private readonly repo: OperatingStatementRepository) {}

  async findAllByDeal(dealPk: string, query: GetOsQueryDto) {
    return this.repo.findAllByDeal(dealPk, query);
  }

  async findOne(osId: string) {
    const os = await this.repo.findWithLineItems(osId);
    if (!os) throw new NotFoundException(`Operating statement ${osId} not found`);
    return os;
  }

  async findLatest(dealPk: string, budgetType?: string) {
    const os = await this.repo.findLatestByDeal(dealPk, budgetType);
    if (!os) throw new NotFoundException(`No operating statement found for deal ${dealPk}`);
    return os;
  }

  async getNOISummary(dealPk: string) {
    return this.repo.getNOISummary(dealPk);
  }

  async create(dealPk: string, dto: CreateOperatingStatementDto, userId?: string) {
    return this.repo.create(dealPk, dto, userId);
  }
}
