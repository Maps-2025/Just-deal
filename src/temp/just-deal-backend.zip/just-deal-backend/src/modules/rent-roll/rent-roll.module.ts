import { Module } from '@nestjs/common';
import { RentRollController } from './rent-roll.controller';
import { RentRollService } from './rent-roll.service';
import { RentRollRepository } from './rent-roll.repository';

@Module({
  controllers: [RentRollController],
  providers: [RentRollService, RentRollRepository],
  exports: [RentRollService],
})
export class RentRollModule {}
