import { Injectable, NotFoundException } from '@nestjs/common';
import { RentRollRepository } from './rent-roll.repository';
import { GetRentRollQueryDto, CreateRentRollDto } from './dto/rent-roll.dto';

@Injectable()
export class RentRollService {
  constructor(private readonly repo: RentRollRepository) {}

  async findAllByDeal(dealPk: string) {
    return this.repo.findAllByDeal(dealPk);
  }

  async findLatestByDeal(dealPk: string) {
    return this.repo.findLatestByDeal(dealPk);
  }

  async getUnits(dealPk: string, query: GetRentRollQueryDto) {
    const latest = await this.repo.findLatestByDeal(dealPk);
    if (!latest) throw new NotFoundException(`No rent roll found for deal ${dealPk}`);
    const units = await this.repo.findUnits(latest.id, query);
    return { rent_roll: latest, ...units };
  }

  async getUnitsByRentRollId(rentRollId: string, query: GetRentRollQueryDto) {
    const rr = await this.repo.findById(rentRollId);
    if (!rr) throw new NotFoundException(`Rent roll ${rentRollId} not found`);
    return this.repo.findUnits(rentRollId, query);
  }

  async getUnitMix(dealPk: string) {
    const latest = await this.repo.findLatestByDeal(dealPk);
    if (!latest) throw new NotFoundException(`No rent roll found for deal ${dealPk}`);
    const mix = await this.repo.getUnitMix(latest.id);
    return { rent_roll_id: latest.id, report_date: latest.report_date, unit_mix: mix };
  }

  async create(dealPk: string, dto: CreateRentRollDto, userId?: string) {
    return this.repo.create(dealPk, dto, userId);
  }
}
