import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../database/prisma.service';
import { GetRentRollQueryDto, CreateRentRollDto } from './dto/rent-roll.dto';
import { Prisma } from '@prisma/client';

@Injectable()
export class RentRollRepository {
  constructor(private readonly prisma: PrismaService) {}

  // List all rent roll snapshots for a deal
  async findAllByDeal(dealPk: string) {
    return this.prisma.rentRoll.findMany({
      where: { deal_pk: dealPk },
      orderBy: { report_date: 'desc' },
      select: {
        id: true,
        report_date: true,
        uploaded_at: true,
        total_units: true,
        occupied_units: true,
        occupancy_pct: true,
        has_anomalies: true,
      },
    });
  }

  // Get latest rent roll for a deal
  async findLatestByDeal(dealPk: string) {
    return this.prisma.rentRoll.findFirst({
      where: { deal_pk: dealPk },
      orderBy: { report_date: 'desc' },
    });
  }

  // Get a rent roll by its ID
  async findById(rentRollId: string) {
    return this.prisma.rentRoll.findUnique({
      where: { id: rentRollId },
    });
  }

  // Get units for a rent roll with filters & pagination
  async findUnits(rentRollId: string, query: GetRentRollQueryDto) {
    const { page = 1, limit = 100, search, occupancy_status, floor_plan, sortBy = 'unit_no', sortOrder = 'asc' } = query;
    const skip = (page - 1) * limit;

    const where: Prisma.RentRollUnitWhereInput = {
      rent_roll_id: rentRollId,
      ...(search && {
        OR: [
          { unit_no: { contains: search, mode: 'insensitive' } },
          { tenant_name: { contains: search, mode: 'insensitive' } },
          { floor_plan: { contains: search, mode: 'insensitive' } },
        ],
      }),
      ...(occupancy_status && { occupancy_status }),
      ...(floor_plan && { floor_plan: { contains: floor_plan, mode: 'insensitive' } }),
    };

    const validSort: Record<string, any> = {
      unit_no: { unit_no: sortOrder },
      market_rent: { market_rent: sortOrder },
      contractual_rent: { contractual_rent: sortOrder },
      bedrooms: { bedrooms: sortOrder },
      net_sqft: { net_sqft: sortOrder },
      lease_end_date: { lease_end_date: sortOrder },
    };

    const [units, total] = await Promise.all([
      this.prisma.rentRollUnit.findMany({
        where,
        skip,
        take: limit,
        orderBy: validSort[sortBy] ?? { unit_no: 'asc' },
      }),
      this.prisma.rentRollUnit.count({ where }),
    ]);

    return { data: units, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  // Floor plan summary (unit mix)
  async getUnitMix(rentRollId: string) {
    const units = await this.prisma.rentRollUnit.findMany({
      where: { rent_roll_id: rentRollId },
      select: {
        floor_plan: true,
        bedrooms: true,
        net_sqft: true,
        market_rent: true,
        contractual_rent: true,
        occupancy_status: true,
      },
    });

    const mix: Record<string, any> = {};
    for (const u of units) {
      const key = u.floor_plan || `${u.bedrooms}BR`;
      if (!mix[key]) {
        mix[key] = {
          floor_plan: key,
          bedrooms: u.bedrooms,
          count: 0,
          occupied: 0,
          avg_sqft: 0,
          avg_market_rent: 0,
          avg_contract_rent: 0,
          total_sqft: 0,
          total_market_rent: 0,
          total_contract_rent: 0,
        };
      }
      mix[key].count++;
      if (u.occupancy_status === 'Occupied') mix[key].occupied++;
      mix[key].total_sqft += u.net_sqft || 0;
      mix[key].total_market_rent += Number(u.market_rent) || 0;
      mix[key].total_contract_rent += Number(u.contractual_rent) || 0;
    }

    return Object.values(mix).map((m: any) => ({
      ...m,
      avg_sqft: m.count ? Math.round(m.total_sqft / m.count) : 0,
      avg_market_rent: m.count ? Math.round(m.total_market_rent / m.count) : 0,
      avg_contract_rent: m.count ? Math.round(m.total_contract_rent / m.count) : 0,
      occupancy_pct: m.count ? Math.round((m.occupied / m.count) * 100 * 10) / 10 : 0,
    }));
  }

  // Create a new rent roll header
  async create(dealPk: string, dto: CreateRentRollDto, userId?: string) {
    return this.prisma.rentRoll.create({
      data: {
        deal_pk: dealPk,
        report_date: new Date(dto.report_date),
        uploaded_by_user_id: userId,
        has_anomalies: dto.has_anomalies ?? false,
        total_units: dto.total_units,
        occupied_units: dto.occupied_units,
        occupancy_pct: dto.occupancy_pct,
      },
    });
  }
}
