import { IsDateString, IsOptional, IsBoolean, IsInt, IsNumber, IsString, Min } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class GetRentRollQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  page?: number = 1;

  @ApiPropertyOptional({ default: 100 })
  @IsOptional()
  @Type(() => Number)
  limit?: number = 100;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  occupancy_status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  floor_plan?: string;

  @ApiPropertyOptional({ default: 'unit_no' })
  @IsOptional()
  @IsString()
  sortBy?: string = 'unit_no';

  @ApiPropertyOptional({ default: 'asc' })
  @IsOptional()
  @IsString()
  sortOrder?: 'asc' | 'desc' = 'asc';
}

export class CreateRentRollDto {
  @ApiProperty({ example: '2025-02-28' })
  @IsDateString()
  report_date: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  has_anomalies?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Min(0)
  total_units?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Min(0)
  occupied_units?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  occupancy_pct?: number;
}
