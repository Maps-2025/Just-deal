import { Controller, Get, Post, Param, Query, Body } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam } from '@nestjs/swagger';
import { RentRollService } from './rent-roll.service';
import { GetRentRollQueryDto, CreateRentRollDto } from './dto/rent-roll.dto';

@ApiTags('rent-roll')
@ApiBearerAuth()
@Controller('deals/:dealId/rent-roll')
export class RentRollController {
  constructor(private readonly rentRollService: RentRollService) {}

  // GET /deals/:dealId/rent-roll — list all snapshots
  @Get()
  @ApiOperation({ summary: 'List all rent roll snapshots for a deal' })
  findAll(@Param('dealId') dealId: string) {
    return this.rentRollService.findAllByDeal(dealId);
  }

  // GET /deals/:dealId/rent-roll/latest — latest snapshot header
  @Get('latest')
  @ApiOperation({ summary: 'Get latest rent roll header for a deal' })
  findLatest(@Param('dealId') dealId: string) {
    return this.rentRollService.findLatestByDeal(dealId);
  }

  // GET /deals/:dealId/rent-roll/units — latest rent roll units (paginated)
  @Get('units')
  @ApiOperation({ summary: 'Get rent roll units for a deal (latest snapshot)' })
  getUnits(
    @Param('dealId') dealId: string,
    @Query() query: GetRentRollQueryDto,
  ) {
    return this.rentRollService.getUnits(dealId, query);
  }

  // GET /deals/:dealId/rent-roll/unit-mix — floor plan summary
  @Get('unit-mix')
  @ApiOperation({ summary: 'Get unit mix summary (floor plan breakdown)' })
  getUnitMix(@Param('dealId') dealId: string) {
    return this.rentRollService.getUnitMix(dealId);
  }

  // POST /deals/:dealId/rent-roll — create rent roll header (for future upload)
  @Post()
  @ApiOperation({ summary: 'Create a new rent roll header record' })
  create(
    @Param('dealId') dealId: string,
    @Body() dto: CreateRentRollDto,
  ) {
    return this.rentRollService.create(dealId, dto);
  }
}
