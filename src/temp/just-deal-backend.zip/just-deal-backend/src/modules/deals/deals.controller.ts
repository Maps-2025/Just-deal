import {
  Controller,
  Get,
  Post,
  Put,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
} from '@nestjs/swagger';
import { DealsService } from './deals.service';
import {
  GetDealsQueryDto,
  CreateDealDto,
  UpdateDealDto,
  UpdateDealStatusDto,
} from './dto/deals.dto';

@ApiTags('deals')
@ApiBearerAuth()
@Controller('deals')
export class DealsController {
  constructor(private readonly dealsService: DealsService) {}

  // ─── GET /deals ─────────────────────────────────────────────────────────────
  @Get()
  @ApiOperation({ summary: 'List all deals with pagination, search, and filters' })
  @ApiResponse({ status: 200, description: 'Paginated list of deals' })
  async findAll(@Query() query: GetDealsQueryDto) {
    return this.dealsService.findAll(query);
  }

  // ─── GET /deals/stats ────────────────────────────────────────────────────────
  @Get('stats')
  @ApiOperation({ summary: 'Get deal summary stats (counts by status, fund)' })
  async getStats() {
    return this.dealsService.getSummaryStats();
  }

  // ─── GET /deals/status-categories ────────────────────────────────────────────
  @Get('status-categories')
  @ApiOperation({ summary: 'Get deal status categories with counts (for filter dropdown)' })
  async getStatusCategories() {
    return this.dealsService.getStatusCategories();
  }

  // ─── GET /deals/:id ──────────────────────────────────────────────────────────
  @Get(':id')
  @ApiOperation({ summary: 'Get full deal details by ID' })
  @ApiParam({ name: 'id', type: 'string' })
  @ApiResponse({ status: 200, description: 'Deal found' })
  @ApiResponse({ status: 404, description: 'Deal not found' })
  async findOne(@Param('id') id: string) {
    return this.dealsService.findOne(id);
  }

  // ─── POST /deals ─────────────────────────────────────────────────────────────
  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a new deal' })
  @ApiResponse({ status: 201, description: 'Deal created' })
  async create(@Body() dto: CreateDealDto) {
    return this.dealsService.create(dto);
  }

  // ─── PUT /deals/:id ───────────────────────────────────────────────────────────
  @Put(':id')
  @ApiOperation({ summary: 'Update a deal' })
  async update(@Param('id') id: string, @Body() dto: UpdateDealDto) {
    return this.dealsService.update(id, dto);
  }

  // ─── PATCH /deals/:id/status ──────────────────────────────────────────────────
  @Patch(':id/status')
  @ApiOperation({ summary: 'Update deal status only' })
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateDealStatusDto,
  ) {
    return this.dealsService.updateStatus(id, dto);
  }

  // ─── PATCH /deals/:id/star ────────────────────────────────────────────────────
  @Patch(':id/star')
  @ApiOperation({ summary: 'Toggle deal starred flag' })
  async toggleStar(@Param('id') id: string) {
    return this.dealsService.toggleStar(id);
  }

  // ─── DELETE /deals/:id ────────────────────────────────────────────────────────
  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Delete a deal' })
  @ApiResponse({ status: 200, description: 'Deal deleted' })
  @ApiResponse({ status: 404, description: 'Deal not found' })
  async remove(@Param('id') id: string) {
    return this.dealsService.remove(id);
  }
}
