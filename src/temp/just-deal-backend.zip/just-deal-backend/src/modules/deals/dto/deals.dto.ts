import {
  IsString,
  IsOptional,
  IsBoolean,
  IsDateString,
  IsIn,
  IsEmail,
  IsNotEmpty,
  IsUUID,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';

export const DEAL_STATUSES = [
  'New',
  'Active',
  'Bid Placed',
  'Closed',
  'Dormant',
  'Passed',
  'Lost',
  'Withdrawn',
  'Exited',
  'Owned Property',
  'Property Comp',
] as const;

// ─── Query / Filter ──────────────────────────────────────────────────────────
export class GetDealsQueryDto {
  @ApiPropertyOptional({ description: 'Search by deal name or deal ID' })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional({ enum: DEAL_STATUSES, isArray: true })
  @IsOptional()
  @Transform(({ value }) => (Array.isArray(value) ? value : [value]))
  status?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  market?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  fund?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  asset_type?: string;

  @ApiPropertyOptional({ default: false })
  @IsOptional()
  @Transform(({ value }) => value === 'true' || value === true)
  @IsBoolean()
  starred?: boolean;

  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  page?: number = 1;

  @ApiPropertyOptional({ default: 25 })
  @IsOptional()
  @Type(() => Number)
  limit?: number = 25;

  @ApiPropertyOptional({ default: 'date_modified' })
  @IsOptional()
  @IsString()
  sortBy?: string = 'date_modified';

  @ApiPropertyOptional({ default: 'desc', enum: ['asc', 'desc'] })
  @IsOptional()
  @IsIn(['asc', 'desc'])
  sortOrder?: 'asc' | 'desc' = 'desc';
}

// ─── Create ──────────────────────────────────────────────────────────────────
export class CreateDealDto {
  @ApiProperty({ example: '03411' })
  @IsNotEmpty()
  @IsString()
  deal_id: string;

  @ApiProperty({ example: 'Maple Grove Apartments' })
  @IsNotEmpty()
  @IsString()
  deal_name: string;

  @ApiProperty({ enum: DEAL_STATUSES, default: 'New' })
  @IsIn(DEAL_STATUSES)
  status: string;

  @ApiProperty({ example: 'Multifamily' })
  @IsNotEmpty()
  @IsString()
  asset_type: string;

  @ApiPropertyOptional({ example: 'Acquisition' })
  @IsOptional()
  @IsString()
  deal_type?: string;

  @ApiPropertyOptional({ example: 'Fund IV' })
  @IsOptional()
  @IsString()
  fund?: string;

  @ApiPropertyOptional({ example: '2025-06-15' })
  @IsOptional()
  @IsDateString()
  bid_due_date?: string;

  @ApiPropertyOptional({ example: '2025-07-01' })
  @IsOptional()
  @IsDateString()
  due_diligence_date?: string;

  @ApiPropertyOptional({ example: 'CBRE' })
  @IsOptional()
  @IsString()
  broker?: string;

  @ApiPropertyOptional({ example: 'broker@cbre.com' })
  @IsOptional()
  @IsEmail()
  broker_email?: string;

  @ApiPropertyOptional({ example: '214-555-0100' })
  @IsOptional()
  @IsString()
  broker_phone?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  comments?: string;

  @ApiPropertyOptional({ default: false })
  @IsOptional()
  @IsBoolean()
  is_starred?: boolean;
}

// ─── Update ──────────────────────────────────────────────────────────────────
export class UpdateDealDto extends PartialType(CreateDealDto) {
  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  flags_r?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  flags_h?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  flags_m?: boolean;
}

// ─── Status Update ───────────────────────────────────────────────────────────
export class UpdateDealStatusDto {
  @ApiProperty({ enum: DEAL_STATUSES })
  @IsIn(DEAL_STATUSES)
  status: string;
}
