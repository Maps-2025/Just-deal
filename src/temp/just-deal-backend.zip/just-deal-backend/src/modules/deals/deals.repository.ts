import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../database/prisma.service';
import { GetDealsQueryDto, CreateDealDto, UpdateDealDto } from './dto/deals.dto';
import { Prisma } from '@prisma/client';

@Injectable()
export class DealsRepository {
  constructor(private readonly prisma: PrismaService) {}

  // ─── List with filters + pagination ────────────────────────────────────────
  async findAll(orgId: string, query: GetDealsQueryDto) {
    const {
      search,
      status,
      market,
      fund,
      asset_type,
      starred,
      page = 1,
      limit = 25,
      sortBy = 'date_modified',
      sortOrder = 'desc',
    } = query;

    const skip = (page - 1) * limit;

    const where: Prisma.DealWhereInput = {
      organization_id: orgId,
      ...(search && {
        OR: [
          { deal_name: { contains: search, mode: 'insensitive' } },
          { deal_id: { contains: search, mode: 'insensitive' } },
          { property: { market: { contains: search, mode: 'insensitive' } } },
        ],
      }),
      ...(status?.length && { status: { in: status } }),
      ...(market && { property: { market: { contains: market, mode: 'insensitive' } } }),
      ...(fund && { fund: { contains: fund, mode: 'insensitive' } }),
      ...(asset_type && { asset_type: { contains: asset_type, mode: 'insensitive' } }),
      ...(starred !== undefined && { is_starred: starred }),
    };

    // Map sortBy to valid Prisma order key
    const validSortFields: Record<string, Prisma.DealOrderByWithRelationInput> = {
      date_modified: { date_modified: sortOrder },
      date_added: { date_added: sortOrder },
      deal_name: { deal_name: sortOrder },
      status: { status: sortOrder },
      bid_due_date: { bid_due_date: sortOrder },
    };

    const orderBy = validSortFields[sortBy] || { date_modified: 'desc' };

    const [data, total] = await Promise.all([
      this.prisma.deal.findMany({
        where,
        skip,
        take: limit,
        orderBy,
        include: {
          property: {
            select: {
              market: true,
              city: true,
              state: true,
              total_units: true,
              address: true,
              building_type: true,
              year_built: true,
            },
          },
        },
      }),
      this.prisma.deal.count({ where }),
    ]);

    return { data, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  // ─── Single deal with full detail ──────────────────────────────────────────
  async findOne(id: string, orgId: string) {
    return this.prisma.deal.findFirst({
      where: { id, organization_id: orgId },
      include: {
        property: true,
        rent_rolls: {
          orderBy: { report_date: 'desc' },
          take: 1,
          select: {
            id: true,
            report_date: true,
            total_units: true,
            occupied_units: true,
            occupancy_pct: true,
            has_anomalies: true,
          },
        },
        operating_statements: {
          orderBy: { uploaded_at: 'desc' },
          take: 1,
          select: {
            id: true,
            period_start: true,
            period_end: true,
            period_type: true,
            budget_type: true,
          },
        },
      },
    });
  }

  // ─── Create ────────────────────────────────────────────────────────────────
  async create(orgId: string, dto: CreateDealDto) {
    return this.prisma.deal.create({
      data: {
        organization_id: orgId,
        deal_id: dto.deal_id,
        deal_name: dto.deal_name,
        status: dto.status,
        asset_type: dto.asset_type,
        deal_type: dto.deal_type,
        fund: dto.fund,
        bid_due_date: dto.bid_due_date ? new Date(dto.bid_due_date) : null,
        due_diligence_date: dto.due_diligence_date ? new Date(dto.due_diligence_date) : null,
        broker: dto.broker,
        broker_email: dto.broker_email,
        broker_phone: dto.broker_phone,
        comments: dto.comments,
        is_starred: dto.is_starred ?? false,
      },
      include: { property: true },
    });
  }

  // ─── Update ────────────────────────────────────────────────────────────────
  async update(id: string, orgId: string, dto: UpdateDealDto) {
    return this.prisma.deal.updateMany({
      where: { id, organization_id: orgId },
      data: {
        ...dto,
        bid_due_date: dto.bid_due_date ? new Date(dto.bid_due_date) : undefined,
        due_diligence_date: dto.due_diligence_date ? new Date(dto.due_diligence_date) : undefined,
        date_modified: new Date(),
      },
    });
  }

  // ─── Toggle star ───────────────────────────────────────────────────────────
  async toggleStar(id: string, orgId: string, starred: boolean) {
    return this.prisma.deal.updateMany({
      where: { id, organization_id: orgId },
      data: { is_starred: starred, date_modified: new Date() },
    });
  }

  // ─── Delete ────────────────────────────────────────────────────────────────
  async remove(id: string, orgId: string) {
    return this.prisma.deal.deleteMany({
      where: { id, organization_id: orgId },
    });
  }

  // ─── Status categories (used by frontend filter dropdowns) ─────────────────
  async getStatusCategories(orgId: string) {
    const results = await this.prisma.deal.groupBy({
      by: ['status'],
      where: { organization_id: orgId },
      _count: { status: true },
    });
    return results.map((r) => ({ status: r.status, count: r._count.status }));
  }

  // ─── Summary stats ─────────────────────────────────────────────────────────
  async getSummaryStats(orgId: string) {
    const [total, byStatus, byFund] = await Promise.all([
      this.prisma.deal.count({ where: { organization_id: orgId } }),
      this.prisma.deal.groupBy({
        by: ['status'],
        where: { organization_id: orgId },
        _count: { status: true },
      }),
      this.prisma.deal.groupBy({
        by: ['fund'],
        where: { organization_id: orgId, fund: { not: null } },
        _count: { fund: true },
      }),
    ]);

    return {
      total,
      by_status: byStatus.map((s) => ({ status: s.status, count: s._count.status })),
      by_fund: byFund.map((f) => ({ fund: f.fund, count: f._count.fund })),
    };
  }
}
