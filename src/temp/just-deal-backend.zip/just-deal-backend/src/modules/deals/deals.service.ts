import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { DealsRepository } from './deals.repository';
import {
  GetDealsQueryDto,
  CreateDealDto,
  UpdateDealDto,
  UpdateDealStatusDto,
} from './dto/deals.dto';

// Default org for Phase 1 (single-org mode — replace with JWT claims in Phase 2)
const DEFAULT_ORG_ID = '00000000-0000-0000-0000-000000000001';

@Injectable()
export class DealsService {
  private readonly logger = new Logger(DealsService.name);

  constructor(private readonly dealsRepo: DealsRepository) {}

  async findAll(query: GetDealsQueryDto, orgId = DEFAULT_ORG_ID) {
    return this.dealsRepo.findAll(orgId, query);
  }

  async findOne(id: string, orgId = DEFAULT_ORG_ID) {
    const deal = await this.dealsRepo.findOne(id, orgId);
    if (!deal) throw new NotFoundException(`Deal ${id} not found`);
    return deal;
  }

  async create(dto: CreateDealDto, orgId = DEFAULT_ORG_ID) {
    const deal = await this.dealsRepo.create(orgId, dto);
    this.logger.log(`Created deal ${deal.id} — "${deal.deal_name}"`);
    return deal;
  }

  async update(id: string, dto: UpdateDealDto, orgId = DEFAULT_ORG_ID) {
    await this.findOne(id, orgId); // ensure exists
    await this.dealsRepo.update(id, orgId, dto);
    return this.findOne(id, orgId);
  }

  async updateStatus(id: string, dto: UpdateDealStatusDto, orgId = DEFAULT_ORG_ID) {
    await this.findOne(id, orgId);
    await this.dealsRepo.update(id, orgId, { status: dto.status });
    return this.findOne(id, orgId);
  }

  async toggleStar(id: string, orgId = DEFAULT_ORG_ID) {
    const deal = await this.findOne(id, orgId);
    await this.dealsRepo.toggleStar(id, orgId, !deal.is_starred);
    return { id, is_starred: !deal.is_starred };
  }

  async remove(id: string, orgId = DEFAULT_ORG_ID) {
    await this.findOne(id, orgId);
    await this.dealsRepo.remove(id, orgId);
    this.logger.log(`Deleted deal ${id}`);
    return { id, deleted: true };
  }

  async getStatusCategories(orgId = DEFAULT_ORG_ID) {
    return this.dealsRepo.getStatusCategories(orgId);
  }

  async getSummaryStats(orgId = DEFAULT_ORG_ID) {
    return this.dealsRepo.getSummaryStats(orgId);
  }
}
