import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../database/prisma.service';
import { LoginDto, RegisterDto } from './dto/auth.dto';
import * as bcrypt from 'bcryptjs';

// NOTE: Phase 1 uses a simple users table without a password column.
// We store a hashed password in a separate map (in-memory for now).
// In Phase 2, add a `password_hash` column to the users table via migration.
const passwordStore = new Map<string, string>();

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
  ) {}

  async register(dto: RegisterDto) {
    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) throw new ConflictException('Email already registered');

    // Create org + user + membership in a transaction
    const result = await this.prisma.$transaction(async (tx) => {
      const org = await tx.organization.create({ data: { name: dto.organization_name } });
      const user = await tx.user.create({ data: { email: dto.email, name: dto.name } });
      await tx.orgMembership.create({
        data: { organization_id: org.id, user_id: user.id, role: 'owner' },
      });
      return { user, org };
    });

    // Store hashed password (use DB column in Phase 2)
    const hash = await bcrypt.hash(dto.password, 10);
    passwordStore.set(result.user.id, hash);

    this.logger.log(`Registered user ${result.user.email} — org: ${result.org.name}`);
    return this._issueToken(result.user.id, result.user.email, result.org.id, 'owner');
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (!user) throw new UnauthorizedException('Invalid credentials');

    const hash = passwordStore.get(user.id);
    // In Phase 1 demo mode — allow any password if no hash stored (seeded users)
    if (hash) {
      const valid = await bcrypt.compare(dto.password, hash);
      if (!valid) throw new UnauthorizedException('Invalid credentials');
    }

    // Get first org membership
    const membership = await this.prisma.orgMembership.findFirst({
      where: { user_id: user.id },
    });

    const orgId = membership?.organization_id ?? '00000000-0000-0000-0000-000000000001';
    const role = membership?.role ?? 'member';

    return this._issueToken(user.id, user.email, orgId, role);
  }

  async getMe(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true, name: true, created_at: true },
    });
    if (!user) throw new UnauthorizedException();

    const membership = await this.prisma.orgMembership.findFirst({
      where: { user_id: userId },
      include: { organization: { select: { id: true, name: true } } },
    });

    return {
      ...user,
      organization: membership?.organization ?? null,
      role: membership?.role ?? null,
    };
  }

  private _issueToken(userId: string, email: string, orgId: string, role: string) {
    const payload = { sub: userId, email, org_id: orgId, role };
    return {
      access_token: this.jwtService.sign(payload),
      user: { id: userId, email, org_id: orgId, role },
    };
  }
}
