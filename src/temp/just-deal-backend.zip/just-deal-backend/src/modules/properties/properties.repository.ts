// ─── properties.repository.ts ────────────────────────────────────────────────
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../database/prisma.service';
import { UpsertPropertyDto } from './dto/properties.dto';

@Injectable()
export class PropertiesRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findByDealId(dealPk: string) {
    return this.prisma.property.findUnique({ where: { deal_pk: dealPk } });
  }

  async upsert(dealPk: string, dto: UpsertPropertyDto) {
    return this.prisma.property.upsert({
      where: { deal_pk: dealPk },
      update: { ...dto },
      create: { deal_pk: dealPk, ...dto },
    });
  }
}
