import { Controller, Get, Put, Param, Body } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { PropertiesService } from './properties.service';
import { UpsertPropertyDto } from './dto/properties.dto';

@ApiTags('properties')
@ApiBearerAuth()
@Controller('deals/:dealId/property')
export class PropertiesController {
  constructor(private readonly propertiesService: PropertiesService) {}

  @Get()
  @ApiOperation({ summary: 'Get property details for a deal' })
  findOne(@Param('dealId') dealId: string) {
    return this.propertiesService.findByDealId(dealId);
  }

  @Put()
  @ApiOperation({ summary: 'Create or update property details for a deal' })
  upsert(@Param('dealId') dealId: string, @Body() dto: UpsertPropertyDto) {
    return this.propertiesService.upsert(dealId, dto);
  }
}
