// ─── properties/dto/properties.dto.ts ────────────────────────────────────────
import {
  IsString, IsOptional, IsNumber, IsBoolean, IsInt, Min,
} from 'class-validator';
import { ApiPropertyOptional, PartialType } from '@nestjs/swagger';

export class UpsertPropertyDto {
  @ApiPropertyOptional() @IsOptional() @IsString() address?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() city?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() state?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() zip?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() market?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() parcel?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() building_type?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() year_built?: number;
  @ApiPropertyOptional() @IsOptional() @IsInt() year_renovated?: number;
  @ApiPropertyOptional() @IsOptional() @IsInt() buildings?: number;
  @ApiPropertyOptional() @IsOptional() @IsInt() stories?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() residential_sqft?: number;
  @ApiPropertyOptional() @IsOptional() @IsInt() @Min(0) total_units?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() acres?: number;
  @ApiPropertyOptional() @IsOptional() @IsInt() parking_spaces?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() asset_quality?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() location_quality?: string;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() age_restricted?: boolean;
  @ApiPropertyOptional() @IsOptional() @IsNumber() affordable_units_pct?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() affordability_status?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() multifamily_housing_type?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() property_manager?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() university_affiliation?: string;
}
