import { Injectable, NotFoundException } from '@nestjs/common';
import { PropertiesRepository } from './properties.repository';
import { UpsertPropertyDto } from './dto/properties.dto';

@Injectable()
export class PropertiesService {
  constructor(private readonly repo: PropertiesRepository) {}

  async findByDealId(dealPk: string) {
    const property = await this.repo.findByDealId(dealPk);
    if (!property) throw new NotFoundException(`Property for deal ${dealPk} not found`);
    return property;
  }

  async upsert(dealPk: string, dto: UpsertPropertyDto) {
    return this.repo.upsert(dealPk, dto);
  }
}
