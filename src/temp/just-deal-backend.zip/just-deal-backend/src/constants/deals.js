const DEAL_STATUSES = [
  'New',
  'Active',
  'Bid Placed',
  'Closed',
  'Dormant',
  'Passed',
  'Lost',
  'Withdrawn',
  'Exited',
  'Owned Property',
  'Property Comp',
];

const DEAL_SORT_FIELDS = [
  'date_modified',
  'date_added',
  'deal_name',
  'status',
  'bid_due_date',
];

const ASSET_TYPES = [
  'Multifamily',
  'Office',
  'Retail',
  'Industrial',
  'Mixed-Use',
  'Land',
];

const PERIOD_TYPES = ['Monthly', 'Annual'];

const BUDGET_TYPES = ['Actuals', 'Proforma 1', 'Proforma 2', 'Proforma 3'];

const ORG_ROLES = ['owner', 'admin', 'member', 'viewer'];

// Default org for Phase 1 single-tenant mode
const DEFAULT_ORG_ID = '11111111-1111-1111-1111-111111111111';

module.exports = {
  DEAL_STATUSES,
  DEAL_SORT_FIELDS,
  ASSET_TYPES,
  PERIOD_TYPES,
  BUDGET_TYPES,
  ORG_ROLES,
  DEFAULT_ORG_ID,
};
