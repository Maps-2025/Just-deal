/**
 * Just Deal — Data Models
 * JavaScript JSDoc type definitions for all entities.
 * These are used for documentation and IDE autocomplete.
 * The actual DB schema lives in prisma/schema.prisma
 */

/**
 * @typedef {Object} Organization
 * @property {string} id
 * @property {string} name
 * @property {Date}   created_at
 */

/**
 * @typedef {Object} User
 * @property {string}  id
 * @property {string}  email
 * @property {string}  [name]
 * @property {Date}    created_at
 */

/**
 * @typedef {Object} OrgMembership
 * @property {string}  id
 * @property {string}  organization_id
 * @property {string}  user_id
 * @property {'owner'|'admin'|'member'|'viewer'} role
 * @property {Date}    created_at
 */

/**
 * @typedef {Object} Deal
 * @property {string}   id
 * @property {string}   organization_id
 * @property {string}   deal_id          - human-readable ID e.g. "03403"
 * @property {string}   deal_name
 * @property {string}   status           - New | Active | Bid Placed | Closed | etc.
 * @property {string}   asset_type       - Multifamily | Office | etc.
 * @property {string}   [deal_type]      - Acquisition | Development | Value-Add
 * @property {string}   [fund]           - Fund III | Fund IV
 * @property {Date}     [bid_due_date]
 * @property {Date}     [due_diligence_date]
 * @property {string}   [broker]
 * @property {string}   [broker_email]
 * @property {string}   [broker_phone]
 * @property {string}   [comments]
 * @property {boolean}  is_starred
 * @property {boolean}  flags_r
 * @property {boolean}  flags_h
 * @property {boolean}  flags_m
 * @property {Date}     date_added
 * @property {Date}     date_modified
 * @property {Property} [property]       - joined
 */

/**
 * @typedef {Object} Property
 * @property {string}  id
 * @property {string}  deal_pk
 * @property {string}  [address]
 * @property {string}  [city]
 * @property {string}  [state]
 * @property {string}  [zip]
 * @property {string}  [market]          - e.g. "Dallas-Fort Worth, TX"
 * @property {string}  [building_type]   - Garden Style | Mid-Rise | High-Rise
 * @property {number}  [year_built]
 * @property {number}  [year_renovated]
 * @property {number}  [buildings]
 * @property {number}  [stories]
 * @property {number}  [residential_sqft]
 * @property {number}  [total_units]
 * @property {number}  [acres]
 * @property {number}  [parking_spaces]
 * @property {string}  [asset_quality]   - A+ | A | A- | B+ | B | B- | C+
 * @property {string}  [location_quality]
 * @property {boolean} [age_restricted]
 * @property {number}  [affordable_units_pct]
 * @property {string}  [multifamily_housing_type] - Conventional | Luxury | Workforce
 * @property {string}  [property_manager]
 * @property {Object}  amenities
 */

/**
 * @typedef {Object} RentRoll
 * @property {string}  id
 * @property {string}  deal_pk
 * @property {Date}    report_date
 * @property {Date}    uploaded_at
 * @property {string}  [uploaded_by_user_id]
 * @property {boolean} has_anomalies
 * @property {number}  [total_units]
 * @property {number}  [occupied_units]
 * @property {number}  [occupancy_pct]
 */

/**
 * @typedef {Object} RentRollUnit
 * @property {string}  id
 * @property {string}  rent_roll_id
 * @property {string}  [unit_no]
 * @property {string}  [floor_plan]
 * @property {number}  [net_sqft]
 * @property {number}  [bedrooms]
 * @property {number}  [bathrooms]
 * @property {string}  [unit_type]
 * @property {string}  [lease_type]
 * @property {string}  [renovation_status] - Classic | Renovated
 * @property {string}  [occupancy_status]  - Occupied | Vacant
 * @property {number}  [market_rent]
 * @property {number}  [contractual_rent]
 * @property {number}  [recurring_concessions]
 * @property {number}  [net_effective_rent]
 * @property {Date}    [lease_start_date]
 * @property {Date}    [lease_end_date]
 * @property {Date}    [move_in_date]
 * @property {Date}    [move_out_date]
 * @property {string}  [tenant_name]
 * @property {number}  [lease_term_months]
 */

/**
 * @typedef {Object} OperatingStatement
 * @property {string} id
 * @property {string} deal_pk
 * @property {Date}   period_start
 * @property {Date}   period_end
 * @property {'Monthly'|'Annual'} period_type
 * @property {'Actuals'|'Proforma 1'|'Proforma 2'|'Proforma 3'} budget_type
 * @property {Date}   uploaded_at
 * @property {string} [uploaded_by_user_id]
 * @property {OperatingStatementLineItem[]} [line_items]
 */

/**
 * @typedef {Object} OperatingStatementLineItem
 * @property {string}  id
 * @property {string}  os_id
 * @property {string}  account_name
 * @property {string}  [account_code]
 * @property {string}  [category]     - Revenue | Operating
 * @property {boolean} is_income
 * @property {number}  amount
 */

/**
 * @typedef {Object} ApiResponse
 * @property {boolean} success
 * @property {string}  message
 * @property {*}       data
 * @property {string}  timestamp
 */

/**
 * @typedef {Object} PaginatedMeta
 * @property {number} total
 * @property {number} page
 * @property {number} limit
 * @property {number} totalPages
 */

module.exports = {};
