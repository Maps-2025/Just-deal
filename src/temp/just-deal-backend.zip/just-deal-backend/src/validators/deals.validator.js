const { body, query, param, validationResult } = require('express-validator');
const { DEAL_STATUSES, ASSET_TYPES } = require('../constants/deals');
const { errorResponse } = require('../utils/response');

// Run validators and return 422 if any fail
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return errorResponse(res, 'Validation failed', 422, errors.array());
  }
  next();
}

const createDealRules = [
  body('deal_id').notEmpty().withMessage('deal_id is required'),
  body('deal_name').notEmpty().withMessage('deal_name is required'),
  body('status').isIn(DEAL_STATUSES).withMessage(`status must be one of: ${DEAL_STATUSES.join(', ')}`),
  body('asset_type').notEmpty().withMessage('asset_type is required'),
  body('broker_email').optional().isEmail().withMessage('Invalid broker email'),
  body('bid_due_date').optional().isISO8601().withMessage('bid_due_date must be a valid date'),
  body('due_diligence_date').optional().isISO8601().withMessage('due_diligence_date must be a valid date'),
];

const updateDealRules = [
  body('status').optional().isIn(DEAL_STATUSES).withMessage(`status must be one of: ${DEAL_STATUSES.join(', ')}`),
  body('broker_email').optional().isEmail().withMessage('Invalid broker email'),
  body('bid_due_date').optional().isISO8601().withMessage('bid_due_date must be a valid date'),
];

const updateStatusRules = [
  body('status').isIn(DEAL_STATUSES).withMessage(`status must be one of: ${DEAL_STATUSES.join(', ')}`),
];

const listDealsRules = [
  query('page').optional().isInt({ min: 1 }).withMessage('page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit must be between 1 and 100'),
  query('sortOrder').optional().isIn(['asc', 'desc']),
];

module.exports = {
  validate,
  createDealRules,
  updateDealRules,
  updateStatusRules,
  listDealsRules,
};
