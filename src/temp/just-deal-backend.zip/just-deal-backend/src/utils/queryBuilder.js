/**
 * Query builder utilities for building Prisma where/orderBy from request query params
 */

function getPagination(query) {
  const page = Math.max(1, parseInt(query.page) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(query.limit) || 25));
  const skip = (page - 1) * limit;
  return { page, limit, skip };
}

function getSortOrder(query, allowedFields, defaultField = 'date_modified') {
  const sortBy = allowedFields.includes(query.sortBy) ? query.sortBy : defaultField;
  const sortOrder = query.sortOrder === 'asc' ? 'asc' : 'desc';
  return { [sortBy]: sortOrder };
}

function buildDealsWhere(query, orgId) {
  const where = { organization_id: orgId };

  if (query.search) {
    where.OR = [
      { deal_name: { contains: query.search, mode: 'insensitive' } },
      { deal_id: { contains: query.search, mode: 'insensitive' } },
      { property: { market: { contains: query.search, mode: 'insensitive' } } },
    ];
  }

  if (query.status) {
    const statuses = Array.isArray(query.status) ? query.status : [query.status];
    where.status = { in: statuses };
  }

  if (query.market) {
    where.property = { market: { contains: query.market, mode: 'insensitive' } };
  }

  if (query.fund) {
    where.fund = { contains: query.fund, mode: 'insensitive' };
  }

  if (query.asset_type) {
    where.asset_type = { contains: query.asset_type, mode: 'insensitive' };
  }

  if (query.starred === 'true' || query.starred === true) {
    where.is_starred = true;
  }

  return where;
}

module.exports = { getPagination, getSortOrder, buildDealsWhere };
