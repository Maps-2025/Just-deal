const isDev = process.env.NODE_ENV !== 'production';

const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
};

function timestamp() {
  return new Date().toISOString();
}

function format(level, color, message, meta) {
  const ts = isDev ? `${colors.gray}${timestamp()}${colors.reset} ` : '';
  const lvl = `${color}[${level}]${colors.reset}`;
  const msg = typeof message === 'object' ? JSON.stringify(message) : message;
  const extra = meta ? ` ${colors.gray}${JSON.stringify(meta)}${colors.reset}` : '';
  return `${ts}${lvl} ${msg}${extra}`;
}

const logger = {
  info: (msg, meta) => console.log(format('INFO', colors.green, msg, meta)),
  warn: (msg, meta) => console.warn(format('WARN', colors.yellow, msg, meta)),
  error: (msg, meta) => console.error(format('ERROR', colors.red, msg, meta)),
  debug: (msg, meta) => {
    if (isDev) console.log(format('DEBUG', colors.cyan, msg, meta));
  },
  http: (msg, meta) => {
    if (isDev) console.log(format('HTTP', colors.blue, msg, meta));
  },
};

module.exports = logger;
