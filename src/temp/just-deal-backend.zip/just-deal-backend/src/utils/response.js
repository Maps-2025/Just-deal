/**
 * Standardized API response helpers
 * All responses follow: { success, data, message, timestamp }
 */

function successResponse(res, data, statusCode = 200, message = 'Success') {
  return res.status(statusCode).json({
    success: true,
    message,
    data,
    timestamp: new Date().toISOString(),
  });
}

function paginatedResponse(res, items, total, page, limit) {
  return res.status(200).json({
    success: true,
    data: items,
    meta: {
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit),
    },
    timestamp: new Date().toISOString(),
  });
}

function errorResponse(res, message, statusCode = 500, errors = null) {
  const body = {
    success: false,
    message,
    timestamp: new Date().toISOString(),
  };
  if (errors) body.errors = errors;
  return res.status(statusCode).json(body);
}

module.exports = { successResponse, paginatedResponse, errorResponse };
