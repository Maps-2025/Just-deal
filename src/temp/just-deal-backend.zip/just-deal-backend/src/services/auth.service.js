const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { prisma } = require('../config/database');
const AppError = require('../utils/AppError');
const jwtConfig = require('../config/jwt');
const { DEFAULT_ORG_ID } = require('../constants/deals');

// Phase 1: store hashed passwords in memory (add password_hash column to users in Phase 2)
const passwordStore = new Map();

class AuthService {
  async register({ email, password, name, organization_name }) {
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) throw AppError.conflict('Email already registered');

    const result = await prisma.$transaction(async (tx) => {
      const org = await tx.organization.create({ data: { name: organization_name } });
      const user = await tx.user.create({ data: { email, name } });
      await tx.orgMembership.create({
        data: { organization_id: org.id, user_id: user.id, role: 'owner' },
      });
      return { user, org };
    });

    const hash = await bcrypt.hash(password, 10);
    passwordStore.set(result.user.id, hash);

    return this._issueToken(result.user, result.org.id, 'owner');
  }

  async login({ email, password }) {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) throw AppError.unauthorized('Invalid credentials');

    const hash = passwordStore.get(user.id);
    // Phase 1 demo mode: seeded users accept any password if no hash stored
    if (hash) {
      const valid = await bcrypt.compare(password, hash);
      if (!valid) throw AppError.unauthorized('Invalid credentials');
    }

    const membership = await prisma.orgMembership.findFirst({
      where: { user_id: user.id },
    });

    const orgId = membership?.organization_id ?? DEFAULT_ORG_ID;
    const role = membership?.role ?? 'member';

    return this._issueToken(user, orgId, role);
  }

  async getMe(userId) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true, name: true, created_at: true },
    });
    if (!user) throw AppError.unauthorized('User not found');

    const membership = await prisma.orgMembership.findFirst({
      where: { user_id: userId },
      include: { organization: { select: { id: true, name: true } } },
    });

    return {
      ...user,
      organization: membership?.organization ?? null,
      role: membership?.role ?? null,
    };
  }

  _issueToken(user, orgId, role) {
    const payload = { sub: user.id, email: user.email, org_id: orgId, role };
    return {
      access_token: jwt.sign(payload, jwtConfig.secret, { expiresIn: jwtConfig.expiresIn }),
      user: { id: user.id, email: user.email, name: user.name, org_id: orgId, role },
    };
  }
}

module.exports = new AuthService();
