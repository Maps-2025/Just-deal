const { prisma } = require('../config/database');
const AppError = require('../utils/AppError');

class OperatingStatementService {
  async findAllByDeal(dealPk, query = {}) {
    const where = { deal_pk: dealPk };
    if (query.budget_type) where.budget_type = query.budget_type;
    if (query.period_type) where.period_type = query.period_type;

    return prisma.operatingStatement.findMany({
      where,
      orderBy: { uploaded_at: 'desc' },
      select: {
        id: true, period_start: true, period_end: true,
        period_type: true, budget_type: true, uploaded_at: true,
      },
    });
  }

  async findById(osId) {
    const os = await prisma.operatingStatement.findUnique({
      where: { id: osId },
      include: {
        line_items: {
          orderBy: [{ is_income: 'desc' }, { account_code: 'asc' }],
        },
      },
    });
    if (!os) throw AppError.notFound(`Operating statement ${osId} not found`);
    return os;
  }

  async findLatest(dealPk, budgetType = 'Actuals') {
    const os = await prisma.operatingStatement.findFirst({
      where: { deal_pk: dealPk, budget_type: budgetType },
      orderBy: { period_end: 'desc' },
      include: {
        line_items: {
          orderBy: [{ is_income: 'desc' }, { account_code: 'asc' }],
        },
      },
    });
    if (!os) throw AppError.notFound(`No operating statement found for deal ${dealPk}`);
    return os;
  }

  async getNOISummary(dealPk) {
    const os = await prisma.operatingStatement.findFirst({
      where: { deal_pk: dealPk, budget_type: 'Actuals' },
      orderBy: { period_end: 'desc' },
      include: { line_items: true },
    });
    if (!os) return null;

    const egi = os.line_items
      .filter((l) => l.is_income)
      .reduce((sum, l) => sum + Number(l.amount), 0);

    const expenses = os.line_items
      .filter((l) => !l.is_income)
      .reduce((sum, l) => sum + Number(l.amount), 0);

    const noi = egi - expenses;

    return {
      os_id: os.id,
      period: `${os.period_start.toISOString().slice(0, 7)} – ${os.period_end.toISOString().slice(0, 7)}`,
      budget_type: os.budget_type,
      effective_gross_income: Math.round(egi),
      total_expenses: Math.round(expenses),
      noi: Math.round(noi),
      expense_ratio: egi > 0 ? Math.round((expenses / egi) * 1000) / 10 : 0,
    };
  }

  async create(dealPk, data, userId) {
    return prisma.operatingStatement.create({
      data: {
        deal_pk: dealPk,
        period_start: new Date(data.period_start),
        period_end: new Date(data.period_end),
        period_type: data.period_type,
        budget_type: data.budget_type,
        uploaded_by_user_id: userId || null,
      },
    });
  }
}

module.exports = new OperatingStatementService();
