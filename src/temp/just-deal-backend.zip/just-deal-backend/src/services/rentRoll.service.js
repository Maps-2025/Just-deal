const { prisma } = require('../config/database');
const AppError = require('../utils/AppError');
const { getPagination } = require('../utils/queryBuilder');

class RentRollService {
  async findAllByDeal(dealPk) {
    return prisma.rentRoll.findMany({
      where: { deal_pk: dealPk },
      orderBy: { report_date: 'desc' },
      select: {
        id: true,
        report_date: true,
        uploaded_at: true,
        total_units: true,
        occupied_units: true,
        occupancy_pct: true,
        has_anomalies: true,
      },
    });
  }

  async findLatest(dealPk) {
    return prisma.rentRoll.findFirst({
      where: { deal_pk: dealPk },
      orderBy: { report_date: 'desc' },
    });
  }

  async getUnits(dealPk, query) {
    const latest = await this.findLatest(dealPk);
    if (!latest) throw AppError.notFound(`No rent roll found for deal ${dealPk}`);

    const { page, limit, skip } = getPagination(query);

    const where = { rent_roll_id: latest.id };
    if (query.search) {
      where.OR = [
        { unit_no: { contains: query.search, mode: 'insensitive' } },
        { tenant_name: { contains: query.search, mode: 'insensitive' } },
        { floor_plan: { contains: query.search, mode: 'insensitive' } },
      ];
    }
    if (query.occupancy_status) where.occupancy_status = query.occupancy_status;
    if (query.floor_plan) where.floor_plan = { contains: query.floor_plan, mode: 'insensitive' };

    const validSort = {
      unit_no: 'unit_no', market_rent: 'market_rent',
      contractual_rent: 'contractual_rent', bedrooms: 'bedrooms',
      net_sqft: 'net_sqft', lease_end_date: 'lease_end_date',
    };
    const sortField = validSort[query.sortBy] || 'unit_no';
    const sortOrder = query.sortOrder === 'desc' ? 'desc' : 'asc';

    const [units, total] = await Promise.all([
      prisma.rentRollUnit.findMany({
        where, skip, take: limit,
        orderBy: { [sortField]: sortOrder },
      }),
      prisma.rentRollUnit.count({ where }),
    ]);

    return { rent_roll: latest, units, total, page, limit };
  }

  async getUnitMix(dealPk) {
    const latest = await this.findLatest(dealPk);
    if (!latest) throw AppError.notFound(`No rent roll found for deal ${dealPk}`);

    const units = await prisma.rentRollUnit.findMany({
      where: { rent_roll_id: latest.id },
      select: {
        floor_plan: true, bedrooms: true, net_sqft: true,
        market_rent: true, contractual_rent: true, occupancy_status: true,
      },
    });

    const mix = {};
    for (const u of units) {
      const key = u.floor_plan || `${u.bedrooms}BR`;
      if (!mix[key]) {
        mix[key] = { floor_plan: key, bedrooms: u.bedrooms, count: 0, occupied: 0,
          total_sqft: 0, total_market_rent: 0, total_contract_rent: 0 };
      }
      mix[key].count++;
      if (u.occupancy_status === 'Occupied') mix[key].occupied++;
      mix[key].total_sqft += u.net_sqft || 0;
      mix[key].total_market_rent += Number(u.market_rent) || 0;
      mix[key].total_contract_rent += Number(u.contractual_rent) || 0;
    }

    const unitMix = Object.values(mix).map((m) => ({
      floor_plan: m.floor_plan,
      bedrooms: m.bedrooms,
      count: m.count,
      occupied: m.occupied,
      avg_sqft: m.count ? Math.round(m.total_sqft / m.count) : 0,
      avg_market_rent: m.count ? Math.round(m.total_market_rent / m.count) : 0,
      avg_contract_rent: m.count ? Math.round(m.total_contract_rent / m.count) : 0,
      occupancy_pct: m.count ? Math.round((m.occupied / m.count) * 1000) / 10 : 0,
    }));

    return { rent_roll_id: latest.id, report_date: latest.report_date, unit_mix: unitMix };
  }

  async create(dealPk, data, userId) {
    return prisma.rentRoll.create({
      data: {
        deal_pk: dealPk,
        report_date: new Date(data.report_date),
        uploaded_by_user_id: userId || null,
        has_anomalies: data.has_anomalies ?? false,
        total_units: data.total_units,
        occupied_units: data.occupied_units,
        occupancy_pct: data.occupancy_pct,
      },
    });
  }
}

module.exports = new RentRollService();
