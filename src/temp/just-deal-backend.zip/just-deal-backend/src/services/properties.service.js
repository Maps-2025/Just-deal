const { prisma } = require('../config/database');
const AppError = require('../utils/AppError');

class PropertiesService {
  async findByDealId(dealPk) {
    const property = await prisma.property.findUnique({ where: { deal_pk: dealPk } });
    if (!property) throw AppError.notFound(`Property for deal ${dealPk} not found`);
    return property;
  }

  async upsert(dealPk, data) {
    return prisma.property.upsert({
      where: { deal_pk: dealPk },
      update: { ...data },
      create: { deal_pk: dealPk, ...data },
    });
  }
}

module.exports = new PropertiesService();
