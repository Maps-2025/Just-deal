const { prisma } = require('../config/database');
const AppError = require('../utils/AppError');
const { getPagination, getSortOrder, buildDealsWhere } = require('../utils/queryBuilder');
const { DEAL_SORT_FIELDS, DEFAULT_ORG_ID } = require('../constants/deals');

class DealsService {

  // ─── List deals with filters + pagination ────────────────────────────────
  async findAll(query, orgId = DEFAULT_ORG_ID) {
    const { page, limit, skip } = getPagination(query);
    const orderBy = getSortOrder(query, DEAL_SORT_FIELDS);
    const where = buildDealsWhere(query, orgId);

    const [deals, total] = await Promise.all([
      prisma.deal.findMany({
        where, skip, take: limit, orderBy,
        include: {
          property: {
            select: {
              id: true, market: true, city: true, state: true,
              total_units: true, address: true, building_type: true, year_built: true,
            },
          },
        },
      }),
      prisma.deal.count({ where }),
    ]);

    return { deals, total, page, limit };
  }

  // ─── Get single deal — full detail ───────────────────────────────────────
  async findById(id, orgId = DEFAULT_ORG_ID) {
    const deal = await prisma.deal.findFirst({
      where: { id, organization_id: orgId },
      include: {
        property: true,
        rent_rolls: {
          orderBy: { report_date: 'desc' },
          take: 1,
          select: {
            id: true, report_date: true, total_units: true,
            occupied_units: true, occupancy_pct: true, has_anomalies: true, uploaded_at: true,
          },
        },
        operating_statements: {
          orderBy: { uploaded_at: 'desc' },
          take: 1,
          select: {
            id: true, period_start: true, period_end: true,
            period_type: true, budget_type: true, uploaded_at: true,
          },
        },
      },
    });

    if (!deal) throw AppError.notFound(`Deal not found`);
    return deal;
  }

  // ─── Create deal (+ property record if address fields provided) ──────────
  async create(data, orgId = DEFAULT_ORG_ID) {
    const { address, city, state, zip, market, ...dealFields } = data;

    const deal = await prisma.deal.create({
      data: {
        organization_id:   orgId,
        deal_id:           dealFields.deal_id,
        deal_name:         dealFields.deal_name,
        status:            dealFields.status || 'New',
        asset_type:        dealFields.asset_type,
        deal_type:         dealFields.deal_type   || null,
        fund:              dealFields.fund         || null,
        bid_due_date:      dealFields.bid_due_date      ? new Date(dealFields.bid_due_date)      : null,
        due_diligence_date:dealFields.due_diligence_date? new Date(dealFields.due_diligence_date): null,
        broker:            dealFields.broker       || null,
        broker_email:      dealFields.broker_email || null,
        broker_phone:      dealFields.broker_phone || null,
        comments:          dealFields.comments     || null,
        is_starred:        dealFields.is_starred   ?? false,
      },
    });

    // Create property record if any location data was provided
    if (address || city || state || zip || market) {
      await prisma.property.create({
        data: { deal_pk: deal.id, address, city, state, zip, market },
      });
    }

    return this.findById(deal.id, orgId);
  }

  // ─── Update deal ──────────────────────────────────────────────────────────
  async update(id, data, orgId = DEFAULT_ORG_ID) {
    await this.findById(id, orgId);

    const updateData = { ...data, date_modified: new Date() };
    if (data.bid_due_date)       updateData.bid_due_date       = new Date(data.bid_due_date);
    if (data.due_diligence_date) updateData.due_diligence_date = new Date(data.due_diligence_date);

    // Strip any fields that aren't on the deal table
    delete updateData.address; delete updateData.city;
    delete updateData.state;   delete updateData.zip;
    delete updateData.market;  delete updateData.property;

    await prisma.deal.updateMany({ where: { id, organization_id: orgId }, data: updateData });
    return this.findById(id, orgId);
  }

  async updateStatus(id, status, orgId = DEFAULT_ORG_ID) {
    await this.findById(id, orgId);
    await prisma.deal.updateMany({
      where: { id, organization_id: orgId },
      data:  { status, date_modified: new Date() },
    });
    return this.findById(id, orgId);
  }

  async toggleStar(id, orgId = DEFAULT_ORG_ID) {
    const deal = await this.findById(id, orgId);
    const newVal = !deal.is_starred;
    await prisma.deal.updateMany({
      where: { id, organization_id: orgId },
      data:  { is_starred: newVal, date_modified: new Date() },
    });
    return { id, is_starred: newVal };
  }

  async delete(id, orgId = DEFAULT_ORG_ID) {
    await this.findById(id, orgId);
    await prisma.deal.deleteMany({ where: { id, organization_id: orgId } });
    return { id, deleted: true };
  }

  async getStatusCategories(orgId = DEFAULT_ORG_ID) {
    const rows = await prisma.deal.groupBy({
      by: ['status'],
      where: { organization_id: orgId },
      _count: { status: true },
    });
    return rows.map((r) => ({ status: r.status, count: r._count.status }));
  }

  async getStats(orgId = DEFAULT_ORG_ID) {
    const [total, byStatus, byFund] = await Promise.all([
      prisma.deal.count({ where: { organization_id: orgId } }),
      prisma.deal.groupBy({
        by: ['status'], where: { organization_id: orgId }, _count: { status: true },
      }),
      prisma.deal.groupBy({
        by: ['fund'], where: { organization_id: orgId, fund: { not: null } }, _count: { fund: true },
      }),
    ]);
    return {
      total,
      by_status: byStatus.map((s) => ({ status: s.status, count: s._count.status })),
      by_fund:   byFund.map((f)   => ({ fund: f.fund,     count: f._count.fund   })),
    };
  }
}

module.exports = new DealsService();
