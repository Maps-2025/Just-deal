module.exports = {
  secret: process.env.JWT_SECRET || 'just-deal-dev-secret',
  expiresIn: process.env.JWT_EXPIRES_IN || '7d',
};
