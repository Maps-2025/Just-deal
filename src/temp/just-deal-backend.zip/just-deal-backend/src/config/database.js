const { PrismaClient } = require('@prisma/client');
const logger = require('../utils/logger');

const prisma = new PrismaClient({
  log:
    process.env.NODE_ENV === 'development'
      ? ['query', 'info', 'warn', 'error']
      : ['warn', 'error'],
});

async function connectDatabase() {
  try {
    await prisma.$connect();
    logger.info('✅ Database connected (Supabase PostgreSQL)');
  } catch (error) {
    logger.error('❌ Database connection failed:', error.message);
    throw error;
  }
}

async function disconnectDatabase() {
  await prisma.$disconnect();
  logger.info('Database disconnected');
}

module.exports = { prisma, connectDatabase, disconnectDatabase };
