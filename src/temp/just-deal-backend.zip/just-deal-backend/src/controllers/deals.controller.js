const dealsService = require('../services/deals.service');
const { successResponse, paginatedResponse } = require('../utils/response');

const listDeals = async (req, res, next) => {
  try {
    const orgId = req.user?.org_id;
    const { deals, total, page, limit } = await dealsService.findAll(req.query, orgId);
    paginatedResponse(res, deals, total, page, limit);
  } catch (err) { next(err); }
};

const getDeal = async (req, res, next) => {
  try {
    const deal = await dealsService.findById(req.params.id, req.user?.org_id);
    successResponse(res, deal);
  } catch (err) { next(err); }
};

const createDeal = async (req, res, next) => {
  try {
    const deal = await dealsService.create(req.body, req.user?.org_id);
    successResponse(res, deal, 201, 'Deal created');
  } catch (err) { next(err); }
};

const updateDeal = async (req, res, next) => {
  try {
    const deal = await dealsService.update(req.params.id, req.body, req.user?.org_id);
    successResponse(res, deal, 200, 'Deal updated');
  } catch (err) { next(err); }
};

const updateDealStatus = async (req, res, next) => {
  try {
    const deal = await dealsService.updateStatus(req.params.id, req.body.status, req.user?.org_id);
    successResponse(res, deal, 200, 'Status updated');
  } catch (err) { next(err); }
};

const toggleStar = async (req, res, next) => {
  try {
    const result = await dealsService.toggleStar(req.params.id, req.user?.org_id);
    successResponse(res, result);
  } catch (err) { next(err); }
};

const deleteDeal = async (req, res, next) => {
  try {
    const result = await dealsService.delete(req.params.id, req.user?.org_id);
    successResponse(res, result, 200, 'Deal deleted');
  } catch (err) { next(err); }
};

const getStats = async (req, res, next) => {
  try {
    const stats = await dealsService.getStats(req.user?.org_id);
    successResponse(res, stats);
  } catch (err) { next(err); }
};

const getStatusCategories = async (req, res, next) => {
  try {
    const categories = await dealsService.getStatusCategories(req.user?.org_id);
    successResponse(res, categories);
  } catch (err) { next(err); }
};

module.exports = {
  listDeals, getDeal, createDeal, updateDeal,
  updateDealStatus, toggleStar, deleteDeal,
  getStats, getStatusCategories,
};
