const propertiesService = require('../services/properties.service');
const { successResponse } = require('../utils/response');

const getProperty = async (req, res, next) => {
  try {
    const property = await propertiesService.findByDealId(req.params.dealId);
    successResponse(res, property);
  } catch (err) { next(err); }
};

const upsertProperty = async (req, res, next) => {
  try {
    const property = await propertiesService.upsert(req.params.dealId, req.body);
    successResponse(res, property, 200, 'Property saved');
  } catch (err) { next(err); }
};

module.exports = { getProperty, upsertProperty };
