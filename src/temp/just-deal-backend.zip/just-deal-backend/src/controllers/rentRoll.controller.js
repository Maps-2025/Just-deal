const rentRollService = require('../services/rentRoll.service');
const { successResponse, paginatedResponse } = require('../utils/response');

const listRentRolls = async (req, res, next) => {
  try {
    const snapshots = await rentRollService.findAllByDeal(req.params.dealId);
    successResponse(res, snapshots);
  } catch (err) { next(err); }
};

const getLatest = async (req, res, next) => {
  try {
    const rr = await rentRollService.findLatest(req.params.dealId);
    successResponse(res, rr);
  } catch (err) { next(err); }
};

const getUnits = async (req, res, next) => {
  try {
    const { rent_roll, units, total, page, limit } =
      await rentRollService.getUnits(req.params.dealId, req.query);
    res.status(200).json({
      success: true,
      rent_roll,
      data: units,
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
      timestamp: new Date().toISOString(),
    });
  } catch (err) { next(err); }
};

const getUnitMix = async (req, res, next) => {
  try {
    const mix = await rentRollService.getUnitMix(req.params.dealId);
    successResponse(res, mix);
  } catch (err) { next(err); }
};

const createRentRoll = async (req, res, next) => {
  try {
    const rr = await rentRollService.create(req.params.dealId, req.body, req.user?.id);
    successResponse(res, rr, 201, 'Rent roll created');
  } catch (err) { next(err); }
};

module.exports = { listRentRolls, getLatest, getUnits, getUnitMix, createRentRoll };
