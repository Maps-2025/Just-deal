const osService = require('../services/operatingStatement.service');
const { successResponse } = require('../utils/response');

const listStatements = async (req, res, next) => {
  try {
    const list = await osService.findAllByDeal(req.params.dealId, req.query);
    successResponse(res, list);
  } catch (err) { next(err); }
};

const getLatest = async (req, res, next) => {
  try {
    const os = await osService.findLatest(req.params.dealId, req.query.budget_type);
    successResponse(res, os);
  } catch (err) { next(err); }
};

const getById = async (req, res, next) => {
  try {
    const os = await osService.findById(req.params.osId);
    successResponse(res, os);
  } catch (err) { next(err); }
};

const getNOI = async (req, res, next) => {
  try {
    const noi = await osService.getNOISummary(req.params.dealId);
    successResponse(res, noi);
  } catch (err) { next(err); }
};

const createStatement = async (req, res, next) => {
  try {
    const os = await osService.create(req.params.dealId, req.body, req.user?.id);
    successResponse(res, os, 201, 'Operating statement created');
  } catch (err) { next(err); }
};

module.exports = { listStatements, getLatest, getById, getNOI, createStatement };
