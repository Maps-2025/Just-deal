const { prisma } = require('../config/database');
const { successResponse } = require('../utils/response');

const listUsers = async (req, res, next) => {
  try {
    const users = await prisma.user.findMany({
      select: { id: true, email: true, name: true, created_at: true },
    });
    successResponse(res, users);
  } catch (err) { next(err); }
};

const getUser = async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.params.id },
      select: { id: true, email: true, name: true, created_at: true },
    });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    successResponse(res, user);
  } catch (err) { next(err); }
};

module.exports = { listUsers, getUser };
