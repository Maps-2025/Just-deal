import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { DatabaseModule } from './database/database.module';
import { DealsModule } from './modules/deals/deals.module';
import { PropertiesModule } from './modules/properties/properties.module';
import { RentRollModule } from './modules/rent-roll/rent-roll.module';
import { OperatingStatementModule } from './modules/operating-statement/operating-statement.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { OrganizationsModule } from './modules/organizations/organizations.module';

@Module({
  imports: [
    // ─── Config ─────────────────────────────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env.local', '.env'],
    }),

    // ─── Rate Limiting ───────────────────────────────────────────────────────
    ThrottlerModule.forRoot([
      { ttl: 60000, limit: 200 },   // 200 req/min general
    ]),

    // ─── Database ────────────────────────────────────────────────────────────
    DatabaseModule,

    // ─── Feature Modules ─────────────────────────────────────────────────────
    AuthModule,
    UsersModule,
    OrganizationsModule,
    DealsModule,
    PropertiesModule,
    RentRollModule,
    OperatingStatementModule,
  ],
})
export class AppModule {}
