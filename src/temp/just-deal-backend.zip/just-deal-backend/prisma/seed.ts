import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding Just Deal database...');

  // ─── Organization ───────────────────────────────────────────────────────────
  const org = await prisma.organization.upsert({
    where: { id: '00000000-0000-0000-0000-000000000001' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000001',
      name: 'Apex Capital Real Estate',
    },
  });

  // ─── Users ──────────────────────────────────────────────────────────────────
  const user1 = await prisma.user.upsert({
    where: { email: 'rahul@apexcapital.com' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000010',
      email: 'rahul@apexcapital.com',
      name: 'Rahul Sharma',
    },
  });

  const user2 = await prisma.user.upsert({
    where: { email: 'analyst@apexcapital.com' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000011',
      email: 'analyst@apexcapital.com',
      name: 'Sarah Chen',
    },
  });

  // ─── Memberships ────────────────────────────────────────────────────────────
  await prisma.orgMembership.upsert({
    where: { id: '00000000-0000-0000-0000-000000000020' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000020',
      organization_id: org.id,
      user_id: user1.id,
      role: 'owner',
    },
  });

  await prisma.orgMembership.upsert({
    where: { id: '00000000-0000-0000-0000-000000000021' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000021',
      organization_id: org.id,
      user_id: user2.id,
      role: 'member',
    },
  });

  // ─── Deals ──────────────────────────────────────────────────────────────────
  const dealsData = [
    {
      id: '10000000-0000-0000-0000-000000000001',
      deal_id: '03403',
      deal_name: '9730 Whitehurst Dr',
      status: 'New',
      asset_type: 'Multifamily',
      deal_type: 'Acquisition',
      fund: 'Fund IV',
      bid_due_date: new Date('2025-04-15'),
      broker: 'Marcus & Millichap',
      broker_email: 'john.smith@marcusmillichap.com',
      broker_phone: '214-555-0101',
      property: {
        address: '9730 Whitehurst Dr',
        city: 'Dallas',
        state: 'TX',
        zip: '75243',
        market: 'Dallas-Fort Worth, TX',
        building_type: 'Garden Style',
        year_built: 1987,
        year_renovated: 2015,
        buildings: 8,
        stories: 3,
        total_units: 52,
        residential_sqft: 42500,
        acres: 3.2,
        parking_spaces: 78,
        asset_quality: 'B',
        location_quality: 'B+',
        age_restricted: false,
        affordable_units_pct: 0,
        multifamily_housing_type: 'Conventional',
      },
    },
    {
      id: '10000000-0000-0000-0000-000000000002',
      deal_id: '03404',
      deal_name: 'Sunset Ridge Apartments',
      status: 'Active',
      asset_type: 'Multifamily',
      deal_type: 'Acquisition',
      fund: 'Fund IV',
      bid_due_date: new Date('2025-04-28'),
      broker: 'CBRE',
      broker_email: 'mike.jones@cbre.com',
      broker_phone: '469-555-0202',
      property: {
        address: '4421 Sunset Ridge Blvd',
        city: 'Fort Worth',
        state: 'TX',
        zip: '76109',
        market: 'Dallas-Fort Worth, TX',
        building_type: 'Mid-Rise',
        year_built: 2001,
        year_renovated: 2019,
        buildings: 3,
        stories: 5,
        total_units: 120,
        residential_sqft: 110000,
        acres: 5.8,
        parking_spaces: 165,
        asset_quality: 'A-',
        location_quality: 'A',
        age_restricted: false,
        affordable_units_pct: 0,
        multifamily_housing_type: 'Conventional',
      },
    },
    {
      id: '10000000-0000-0000-0000-000000000003',
      deal_id: '03405',
      deal_name: 'The Meridian at Oak Lawn',
      status: 'Bid Placed',
      asset_type: 'Multifamily',
      deal_type: 'Acquisition',
      fund: 'Fund III',
      bid_due_date: new Date('2025-03-30'),
      broker: 'JLL',
      broker_email: 'lisa.park@jll.com',
      broker_phone: '214-555-0303',
      property: {
        address: '3850 Oak Lawn Ave',
        city: 'Dallas',
        state: 'TX',
        zip: '75219',
        market: 'Dallas-Fort Worth, TX',
        building_type: 'High-Rise',
        year_built: 2008,
        buildings: 1,
        stories: 12,
        total_units: 210,
        residential_sqft: 225000,
        acres: 2.1,
        parking_spaces: 285,
        asset_quality: 'A',
        location_quality: 'A+',
        age_restricted: false,
        affordable_units_pct: 5,
        multifamily_housing_type: 'Luxury',
      },
    },
    {
      id: '10000000-0000-0000-0000-000000000004',
      deal_id: '03406',
      deal_name: 'Lakewood Commons',
      status: 'Dormant',
      asset_type: 'Multifamily',
      deal_type: 'Development',
      fund: 'Fund III',
      broker: 'Newmark',
      broker_email: 'tom.williams@newmark.com',
      broker_phone: '214-555-0404',
      property: {
        address: '6200 Gaston Ave',
        city: 'Dallas',
        state: 'TX',
        zip: '75214',
        market: 'Dallas-Fort Worth, TX',
        building_type: 'Garden Style',
        year_built: 1975,
        year_renovated: 2008,
        buildings: 12,
        stories: 2,
        total_units: 88,
        residential_sqft: 74000,
        acres: 6.4,
        parking_spaces: 130,
        asset_quality: 'C+',
        location_quality: 'B',
        age_restricted: false,
        affordable_units_pct: 15,
        multifamily_housing_type: 'Workforce',
      },
    },
    {
      id: '10000000-0000-0000-0000-000000000005',
      deal_id: '03407',
      deal_name: 'Plano Tech Corridor Apts',
      status: 'Active',
      asset_type: 'Multifamily',
      deal_type: 'Acquisition',
      fund: 'Fund IV',
      bid_due_date: new Date('2025-05-10'),
      broker: 'Cushman & Wakefield',
      broker_email: 'amy.taylor@cushwake.com',
      broker_phone: '972-555-0505',
      property: {
        address: '1500 Tennyson Pkwy',
        city: 'Plano',
        state: 'TX',
        zip: '75075',
        market: 'Dallas-Fort Worth, TX',
        building_type: 'Garden Style',
        year_built: 2016,
        buildings: 6,
        stories: 3,
        total_units: 168,
        residential_sqft: 158000,
        acres: 9.2,
        parking_spaces: 240,
        asset_quality: 'A-',
        location_quality: 'A',
        age_restricted: false,
        affordable_units_pct: 0,
        multifamily_housing_type: 'Conventional',
      },
    },
    {
      id: '10000000-0000-0000-0000-000000000006',
      deal_id: '03408',
      deal_name: 'Austin East Riverside',
      status: 'Closed',
      asset_type: 'Multifamily',
      deal_type: 'Acquisition',
      fund: 'Fund II',
      property: {
        address: '2100 E Riverside Dr',
        city: 'Austin',
        state: 'TX',
        zip: '78741',
        market: 'Austin, TX',
        building_type: 'Garden Style',
        year_built: 1998,
        year_renovated: 2020,
        buildings: 10,
        stories: 2,
        total_units: 144,
        residential_sqft: 126000,
        acres: 8.5,
        parking_spaces: 200,
        asset_quality: 'B+',
        location_quality: 'A-',
        age_restricted: false,
        affordable_units_pct: 0,
        multifamily_housing_type: 'Conventional',
      },
    },
    {
      id: '10000000-0000-0000-0000-000000000007',
      deal_id: '03409',
      deal_name: 'Houston Galleria Flats',
      status: 'Passed',
      asset_type: 'Multifamily',
      deal_type: 'Acquisition',
      fund: 'Fund IV',
      broker: 'Walker & Dunlop',
      broker_email: 'david.brown@walkerdunlop.com',
      broker_phone: '713-555-0707',
      property: {
        address: '5050 Westheimer Rd',
        city: 'Houston',
        state: 'TX',
        zip: '77056',
        market: 'Houston, TX',
        building_type: 'Mid-Rise',
        year_built: 2005,
        buildings: 2,
        stories: 6,
        total_units: 96,
        residential_sqft: 95000,
        acres: 3.0,
        parking_spaces: 130,
        asset_quality: 'B+',
        location_quality: 'A',
        age_restricted: false,
        affordable_units_pct: 0,
        multifamily_housing_type: 'Conventional',
      },
    },
    {
      id: '10000000-0000-0000-0000-000000000008',
      deal_id: '03410',
      deal_name: 'The Grove at Frisco',
      status: 'Active',
      asset_type: 'Multifamily',
      deal_type: 'Value-Add',
      fund: 'Fund IV',
      bid_due_date: new Date('2025-06-01'),
      broker: 'Berkadia',
      broker_email: 'james.wilson@berkadia.com',
      broker_phone: '972-555-0808',
      is_starred: true,
      property: {
        address: '8800 Legacy Dr',
        city: 'Frisco',
        state: 'TX',
        zip: '75034',
        market: 'Dallas-Fort Worth, TX',
        building_type: 'Garden Style',
        year_built: 2012,
        buildings: 15,
        stories: 3,
        total_units: 312,
        residential_sqft: 310000,
        acres: 18.5,
        parking_spaces: 450,
        asset_quality: 'A-',
        location_quality: 'A+',
        age_restricted: false,
        affordable_units_pct: 0,
        multifamily_housing_type: 'Conventional',
      },
    },
  ];

  for (const dealData of dealsData) {
    const { property: propData, ...deal } = dealData;

    const createdDeal = await prisma.deal.upsert({
      where: { id: deal.id },
      update: {},
      create: {
        ...deal,
        organization_id: org.id,
        comments: `Sourced via broker. Initial underwriting review complete.`,
      },
    });

    if (propData) {
      await prisma.property.upsert({
        where: { deal_pk: createdDeal.id },
        update: {},
        create: {
          deal_pk: createdDeal.id,
          ...propData,
          residential_sqft: propData.residential_sqft,
          acres: propData.acres,
          affordable_units_pct: propData.affordable_units_pct,
        },
      });
    }
  }

  // ─── Rent Rolls for Deal 1 (9730 Whitehurst Dr) ─────────────────────────────
  const rr1 = await prisma.rentRoll.upsert({
    where: { id: '20000000-0000-0000-0000-000000000001' },
    update: {},
    create: {
      id: '20000000-0000-0000-0000-000000000001',
      deal_pk: '10000000-0000-0000-0000-000000000001',
      report_date: new Date('2025-02-28'),
      uploaded_by_user_id: user1.id,
      total_units: 52,
      occupied_units: 47,
      occupancy_pct: 90.38,
    },
  });

  const units1 = [
    { unit_no: '101', floor_plan: '1BR/1BA', bedrooms: 1, bathrooms: 1, net_sqft: 650, tenant_name: 'Johnson, M.', market_rent: 1095, contractual_rent: 1050, occupancy_status: 'Occupied', lease_start_date: new Date('2024-09-01'), lease_end_date: new Date('2025-08-31') },
    { unit_no: '102', floor_plan: '1BR/1BA', bedrooms: 1, bathrooms: 1, net_sqft: 650, tenant_name: 'Davis, K.', market_rent: 1095, contractual_rent: 1095, occupancy_status: 'Occupied', lease_start_date: new Date('2024-11-01'), lease_end_date: new Date('2025-10-31') },
    { unit_no: '103', floor_plan: '2BR/1BA', bedrooms: 2, bathrooms: 1, net_sqft: 850, tenant_name: 'Smith, R.', market_rent: 1350, contractual_rent: 1295, occupancy_status: 'Occupied', lease_start_date: new Date('2024-07-01'), lease_end_date: new Date('2025-06-30') },
    { unit_no: '104', floor_plan: '2BR/2BA', bedrooms: 2, bathrooms: 2, net_sqft: 975, tenant_name: 'Garcia, L.', market_rent: 1495, contractual_rent: 1450, occupancy_status: 'Occupied', lease_start_date: new Date('2025-01-01'), lease_end_date: new Date('2025-12-31') },
    { unit_no: '105', floor_plan: '1BR/1BA', bedrooms: 1, bathrooms: 1, net_sqft: 650, tenant_name: null, market_rent: 1095, contractual_rent: null, occupancy_status: 'Vacant' },
    { unit_no: '201', floor_plan: '1BR/1BA', bedrooms: 1, bathrooms: 1, net_sqft: 650, tenant_name: 'Martinez, C.', market_rent: 1095, contractual_rent: 1075, occupancy_status: 'Occupied', lease_start_date: new Date('2024-10-01'), lease_end_date: new Date('2025-09-30') },
    { unit_no: '202', floor_plan: '2BR/1BA', bedrooms: 2, bathrooms: 1, net_sqft: 850, tenant_name: 'Wilson, T.', market_rent: 1350, contractual_rent: 1350, occupancy_status: 'Occupied', lease_start_date: new Date('2025-02-01'), lease_end_date: new Date('2026-01-31') },
    { unit_no: '203', floor_plan: '2BR/2BA', bedrooms: 2, bathrooms: 2, net_sqft: 975, tenant_name: 'Anderson, P.', market_rent: 1495, contractual_rent: 1425, occupancy_status: 'Occupied', lease_start_date: new Date('2024-06-01'), lease_end_date: new Date('2025-05-31') },
    { unit_no: '204', floor_plan: '3BR/2BA', bedrooms: 3, bathrooms: 2, net_sqft: 1200, tenant_name: 'Thompson, J.', market_rent: 1750, contractual_rent: 1695, occupancy_status: 'Occupied', lease_start_date: new Date('2024-08-01'), lease_end_date: new Date('2025-07-31') },
    { unit_no: '205', floor_plan: '1BR/1BA', bedrooms: 1, bathrooms: 1, net_sqft: 650, tenant_name: 'Jackson, M.', market_rent: 1095, contractual_rent: 1095, occupancy_status: 'Occupied', lease_start_date: new Date('2025-01-15'), lease_end_date: new Date('2026-01-14') },
    { unit_no: '301', floor_plan: '2BR/2BA', bedrooms: 2, bathrooms: 2, net_sqft: 975, tenant_name: 'White, S.', market_rent: 1495, contractual_rent: 1450, occupancy_status: 'Occupied', lease_start_date: new Date('2024-12-01'), lease_end_date: new Date('2025-11-30') },
    { unit_no: '302', floor_plan: '1BR/1BA', bedrooms: 1, bathrooms: 1, net_sqft: 650, tenant_name: null, market_rent: 1095, contractual_rent: null, occupancy_status: 'Vacant' },
    { unit_no: '303', floor_plan: '3BR/2BA', bedrooms: 3, bathrooms: 2, net_sqft: 1200, tenant_name: 'Harris, D.', market_rent: 1750, contractual_rent: 1700, occupancy_status: 'Occupied', lease_start_date: new Date('2024-09-15'), lease_end_date: new Date('2025-09-14') },
    { unit_no: '304', floor_plan: '2BR/1BA', bedrooms: 2, bathrooms: 1, net_sqft: 850, tenant_name: 'Clark, B.', market_rent: 1350, contractual_rent: 1300, occupancy_status: 'Occupied', lease_start_date: new Date('2024-05-01'), lease_end_date: new Date('2025-04-30') },
    { unit_no: '305', floor_plan: '2BR/2BA', bedrooms: 2, bathrooms: 2, net_sqft: 975, tenant_name: 'Lewis, A.', market_rent: 1495, contractual_rent: 1495, occupancy_status: 'Occupied', lease_start_date: new Date('2025-02-15'), lease_end_date: new Date('2026-02-14') },
  ];

  for (let i = 0; i < units1.length; i++) {
    await prisma.rentRollUnit.upsert({
      where: { id: `30000000-0000-0000-0000-${String(i + 1).padStart(12, '0')}` },
      update: {},
      create: {
        id: `30000000-0000-0000-0000-${String(i + 1).padStart(12, '0')}`,
        rent_roll_id: rr1.id,
        ...units1[i],
        net_effective_rent: units1[i].contractual_rent,
        lease_type: 'Market Rate',
        renovation_status: Math.random() > 0.6 ? 'Renovated' : 'Classic',
        unit_type: units1[i].bedrooms === 1 ? '1BR' : units1[i].bedrooms === 2 ? '2BR' : '3BR',
      },
    });
  }

  // ─── Operating Statement for Deal 1 ─────────────────────────────────────────
  const os1 = await prisma.operatingStatement.upsert({
    where: { id: '40000000-0000-0000-0000-000000000001' },
    update: {},
    create: {
      id: '40000000-0000-0000-0000-000000000001',
      deal_pk: '10000000-0000-0000-0000-000000000001',
      period_start: new Date('2024-01-01'),
      period_end: new Date('2024-12-31'),
      period_type: 'Annual',
      budget_type: 'Actuals',
      uploaded_by_user_id: user1.id,
    },
  });

  const lineItems = [
    { account_name: 'Gross Potential Rent', account_code: '4000', category: 'Revenue', is_income: true, amount: 720000 },
    { account_name: 'Loss to Lease', account_code: '4010', category: 'Revenue', is_income: true, amount: -18000 },
    { account_name: 'Vacancy Loss', account_code: '4020', category: 'Revenue', is_income: true, amount: -43200 },
    { account_name: 'Bad Debt', account_code: '4030', category: 'Revenue', is_income: true, amount: -7200 },
    { account_name: 'Other Income', account_code: '4100', category: 'Revenue', is_income: true, amount: 28000 },
    { account_name: 'Repairs & Maintenance', account_code: '5100', category: 'Operating', is_income: false, amount: 48000 },
    { account_name: 'Payroll & Benefits', account_code: '5200', category: 'Operating', is_income: false, amount: 95000 },
    { account_name: 'Utilities', account_code: '5300', category: 'Operating', is_income: false, amount: 36000 },
    { account_name: 'Insurance', account_code: '5400', category: 'Operating', is_income: false, amount: 22000 },
    { account_name: 'Real Estate Taxes', account_code: '5500', category: 'Operating', is_income: false, amount: 55000 },
    { account_name: 'Management Fee', account_code: '5600', category: 'Operating', is_income: false, amount: 33600 },
    { account_name: 'Marketing & Leasing', account_code: '5700', category: 'Operating', is_income: false, amount: 12000 },
    { account_name: 'General & Administrative', account_code: '5800', category: 'Operating', is_income: false, amount: 18000 },
  ];

  for (let i = 0; i < lineItems.length; i++) {
    await prisma.operatingStatementLineItem.upsert({
      where: { id: `50000000-0000-0000-0000-${String(i + 1).padStart(12, '0')}` },
      update: {},
      create: {
        id: `50000000-0000-0000-0000-${String(i + 1).padStart(12, '0')}`,
        os_id: os1.id,
        ...lineItems[i],
      },
    });
  }

  console.log('✅ Seeding complete!');
  console.log(`   - 1 organization`);
  console.log(`   - 2 users`);
  console.log(`   - ${dealsData.length} deals with properties`);
  console.log(`   - 1 rent roll with ${units1.length} units`);
  console.log(`   - 1 operating statement with ${lineItems.length} line items`);
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => {
    console.error(e);
    prisma.$disconnect();
    process.exit(1);
  });
