/**
 * just-deal — Frontend API Service Layer
 * Paste this file into: frontend/src/services/api.ts
 *
 * Works with the just-deal-backend NestJS API.
 * Set NEXT_PUBLIC_API_URL in your .env.local
 */

const BASE_URL =
  process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:3001/api/v1';

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('just_deal_token');
}

async function request<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers as Record<string, string>),
  };

  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(err.message ?? 'API error');
  }

  const json = await res.json();
  // Backend wraps all responses in { success, data, timestamp }
  return 'data' in json ? json.data : json;
}

function buildQuery(params: Record<string, any>): string {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '') continue;
    if (Array.isArray(v)) v.forEach((val) => q.append(k, val));
    else q.set(k, String(v));
  }
  const str = q.toString();
  return str ? `?${str}` : '';
}

// ─── Types ───────────────────────────────────────────────────────────────────

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface Deal {
  id: string;
  deal_id: string;
  deal_name: string;
  status: string;
  asset_type: string;
  deal_type?: string;
  fund?: string;
  bid_due_date?: string;
  due_diligence_date?: string;
  broker?: string;
  broker_email?: string;
  broker_phone?: string;
  comments?: string;
  is_starred: boolean;
  flags_r: boolean;
  flags_h: boolean;
  flags_m: boolean;
  date_added: string;
  date_modified: string;
  property?: Property;
  rent_rolls?: RentRollSummary[];
  operating_statements?: OsSummary[];
}

export interface Property {
  id: string;
  deal_pk: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  market?: string;
  building_type?: string;
  year_built?: number;
  year_renovated?: number;
  buildings?: number;
  stories?: number;
  residential_sqft?: number;
  total_units?: number;
  acres?: number;
  parking_spaces?: number;
  asset_quality?: string;
  location_quality?: string;
  age_restricted?: boolean;
  affordable_units_pct?: number;
  affordability_status?: string;
  multifamily_housing_type?: string;
  property_manager?: string;
  amenities: Record<string, any>;
}

export interface RentRollSummary {
  id: string;
  report_date: string;
  total_units?: number;
  occupied_units?: number;
  occupancy_pct?: number;
  has_anomalies: boolean;
}

export interface RentRollUnit {
  id: string;
  unit_no?: string;
  floor_plan?: string;
  bedrooms?: number;
  bathrooms?: number;
  net_sqft?: number;
  unit_type?: string;
  lease_type?: string;
  renovation_status?: string;
  occupancy_status?: string;
  market_rent?: number;
  contractual_rent?: number;
  net_effective_rent?: number;
  recurring_concessions?: number;
  lease_start_date?: string;
  lease_end_date?: string;
  tenant_name?: string;
  lease_term_months?: number;
}

export interface UnitMixRow {
  floor_plan: string;
  bedrooms?: number;
  count: number;
  occupied: number;
  avg_sqft: number;
  avg_market_rent: number;
  avg_contract_rent: number;
  occupancy_pct: number;
}

export interface OsSummary {
  id: string;
  period_start: string;
  period_end: string;
  period_type: string;
  budget_type: string;
}

export interface OsLineItem {
  id: string;
  account_name: string;
  account_code?: string;
  category?: string;
  is_income: boolean;
  amount: number;
}

export interface OperatingStatement extends OsSummary {
  line_items: OsLineItem[];
}

export interface NOISummary {
  os_id: string;
  period: string;
  budget_type: string;
  effective_gross_income: number;
  total_expenses: number;
  noi: number;
  expense_ratio: number;
}

export interface DealStats {
  total: number;
  by_status: { status: string; count: number }[];
  by_fund: { fund: string; count: number }[];
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

export const authApi = {
  login: (email: string, password: string) =>
    request<{ access_token: string; user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (data: {
    email: string;
    password: string;
    name: string;
    organization_name: string;
  }) =>
    request<{ access_token: string; user: any }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  me: () => request<any>('/auth/me'),
};

// ─── Deals ────────────────────────────────────────────────────────────────────

export interface GetDealsParams {
  search?: string;
  status?: string | string[];
  market?: string;
  fund?: string;
  starred?: boolean;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export const dealsApi = {
  list: (params: GetDealsParams = {}) =>
    request<PaginatedResponse<Deal>>(`/deals${buildQuery(params)}`),

  get: (id: string) => request<Deal>(`/deals/${id}`),

  stats: () => request<DealStats>('/deals/stats'),

  statusCategories: () =>
    request<{ status: string; count: number }[]>('/deals/status-categories'),

  create: (data: Partial<Deal>) =>
    request<Deal>('/deals', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<Deal>) =>
    request<Deal>(`/deals/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  updateStatus: (id: string, status: string) =>
    request<Deal>(`/deals/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  toggleStar: (id: string) =>
    request<{ id: string; is_starred: boolean }>(`/deals/${id}/star`, {
      method: 'PATCH',
    }),

  delete: (id: string) =>
    request<{ id: string; deleted: boolean }>(`/deals/${id}`, {
      method: 'DELETE',
    }),
};

// ─── Properties ───────────────────────────────────────────────────────────────

export const propertiesApi = {
  get: (dealId: string) =>
    request<Property>(`/deals/${dealId}/property`),

  upsert: (dealId: string, data: Partial<Property>) =>
    request<Property>(`/deals/${dealId}/property`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
};

// ─── Rent Roll ────────────────────────────────────────────────────────────────

export interface GetUnitsParams {
  page?: number;
  limit?: number;
  search?: string;
  occupancy_status?: string;
  floor_plan?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export const rentRollApi = {
  list: (dealId: string) =>
    request<RentRollSummary[]>(`/deals/${dealId}/rent-roll`),

  latest: (dealId: string) =>
    request<RentRollSummary>(`/deals/${dealId}/rent-roll/latest`),

  units: (dealId: string, params: GetUnitsParams = {}) =>
    request<
      PaginatedResponse<RentRollUnit> & { rent_roll: RentRollSummary }
    >(`/deals/${dealId}/rent-roll/units${buildQuery(params)}`),

  unitMix: (dealId: string) =>
    request<{ rent_roll_id: string; report_date: string; unit_mix: UnitMixRow[] }>(
      `/deals/${dealId}/rent-roll/unit-mix`,
    ),
};

// ─── Operating Statement ──────────────────────────────────────────────────────

export const operatingStatementApi = {
  list: (dealId: string, params: { budget_type?: string; period_type?: string } = {}) =>
    request<OsSummary[]>(`/deals/${dealId}/operating-statement${buildQuery(params)}`),

  latest: (dealId: string, budgetType?: string) =>
    request<OperatingStatement>(
      `/deals/${dealId}/operating-statement/latest${budgetType ? `?budget_type=${budgetType}` : ''}`,
    ),

  get: (dealId: string, osId: string) =>
    request<OperatingStatement>(`/deals/${dealId}/operating-statement/${osId}`),

  noi: (dealId: string) =>
    request<NOISummary>(`/deals/${dealId}/operating-statement/noi-summary`),
};
