# Just Deal Backend — Express.js + Node.js

Production-grade REST API for the **Just Deal** real estate deals analysis platform.
Designed to pair with the **Just-deal** Lovable frontend.

---

## Stack

| Layer       | Tech                        |
|-------------|-----------------------------|
| Runtime     | Node.js 18+                 |
| Framework   | Express.js 4                |
| ORM         | Prisma 5                    |
| Database    | PostgreSQL (Supabase)       |
| Auth        | JWT (jsonwebtoken)          |
| Validation  | express-validator           |
| Security    | helmet, cors, rate-limiting |

---

## Folder Structure

```
src/
├── server.js               ← Entry point (starts server)
├── app.js                  ← Express app (middleware + routes)
├── config/
│   ├── database.js         ← Prisma client singleton
│   └── jwt.js              ← JWT secret + expiry config
├── constants/
│   ├── deals.js            ← Statuses, asset types, sort fields
│   └── httpStatus.js       ← HTTP status codes
├── controllers/
│   ├── auth.controller.js
│   ├── deals.controller.js
│   ├── properties.controller.js
│   ├── rentRoll.controller.js
│   ├── operatingStatement.controller.js
│   └── users.controller.js
├── middlewares/
│   ├── auth.js             ← JWT authenticate + optionalAuth
│   ├── errorHandler.js     ← Global error handler
│   ├── notFound.js         ← 404 handler
│   ├── rateLimiter.js      ← 300 req/min limiter
│   └── requestLogger.js    ← HTTP request logging
├── models/
│   └── index.js            ← JSDoc type definitions
├── routes/
│   ├── auth.routes.js
│   ├── deals.routes.js
│   ├── properties.routes.js
│   ├── rentRoll.routes.js
│   ├── operatingStatement.routes.js
│   └── users.routes.js
├── services/
│   ├── auth.service.js
│   ├── deals.service.js
│   ├── properties.service.js
│   ├── rentRoll.service.js
│   └── operatingStatement.service.js
├── utils/
│   ├── AppError.js         ← Custom error class
│   ├── logger.js           ← Colored console logger
│   ├── queryBuilder.js     ← Prisma filter/sort helpers
│   └── response.js         ← Standardized JSON responses
├── validators/
│   ├── auth.validator.js
│   └── deals.validator.js
└── database/
    └── seed.js             ← Dummy data: 8 deals + rent roll + OS
```

---

## Quick Start (3 steps)

### Step 1 — Install

```bash
cd just-deal-backend
npm install
```

### Step 2 — Configure

```bash
cp .env.example .env
```

Open `.env` and fill in your **Supabase** values:

```env
DATABASE_URL="postgresql://postgres.[REF]:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres?pgbouncer=true"
DIRECT_URL="postgresql://postgres.[REF]:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:5432/postgres"
JWT_SECRET=any-random-string-here
```

> **Where to get these:**
> Supabase Dashboard → Settings → Database → Connection string (Transaction Pooler)

### Step 3 — Initialize DB + Start

```bash
# Generate Prisma client
npx prisma generate

# Push schema to Supabase (creates all tables)
npx prisma db push

# Load dummy data (8 deals, rent roll, operating statement)
node src/database/seed.js

# Start development server (hot reload)
npm run dev
```

✅ **API running at:** `http://localhost:3001/api/v1`
✅ **Health check:** `http://localhost:3001/api/v1/health`

---

## All API Endpoints

### Auth
```
POST   /api/v1/auth/register        Register user + org
POST   /api/v1/auth/login           Login → JWT token
GET    /api/v1/auth/me              Current user info (protected)
```

**Demo login (Phase 1 — any password works for seeded users):**
```bash
curl -X POST http://localhost:3001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"rahul@apexcapital.com","password":"demo123"}'
```

---

### Deals
```
GET    /api/v1/deals                     List (paginated + filtered)
GET    /api/v1/deals/stats               Counts by status + fund
GET    /api/v1/deals/status-categories   Status dropdown options
GET    /api/v1/deals/:id                 Full deal detail
POST   /api/v1/deals                     Create deal
PUT    /api/v1/deals/:id                 Update deal
PATCH  /api/v1/deals/:id/status          Update status only
PATCH  /api/v1/deals/:id/star            Toggle starred ⭐
DELETE /api/v1/deals/:id                 Delete deal
```

**Query params for GET /deals:**
```
search        fuzzy search on name, ID, market
status        filter by status (repeatable: ?status=New&status=Active)
market        filter by market name
fund          filter by fund name
starred       true/false
page          default: 1
limit         default: 25  (max: 100)
sortBy        date_modified | date_added | deal_name | status | bid_due_date
sortOrder     asc | desc
```

**Response format (paginated):**
```json
{
  "success": true,
  "data": [ ...deals ],
  "meta": { "total": 8, "page": 1, "limit": 25, "totalPages": 1 },
  "timestamp": "2025-03-16T10:00:00.000Z"
}
```

---

### Properties
```
GET    /api/v1/deals/:dealId/property    Get property details
PUT    /api/v1/deals/:dealId/property    Create or update property
```

---

### Rent Roll
```
GET    /api/v1/deals/:dealId/rent-roll             All snapshots list
GET    /api/v1/deals/:dealId/rent-roll/latest      Latest header
GET    /api/v1/deals/:dealId/rent-roll/units       Paginated unit rows
GET    /api/v1/deals/:dealId/rent-roll/unit-mix    Floor plan summary
POST   /api/v1/deals/:dealId/rent-roll             Create header
```

**Query params for /units:**
```
search            search unit_no, tenant_name, floor_plan
occupancy_status  Occupied | Vacant
floor_plan        1BR/1BA etc.
page, limit, sortBy, sortOrder
```

---

### Operating Statement
```
GET    /api/v1/deals/:dealId/operating-statement             List all
GET    /api/v1/deals/:dealId/operating-statement/latest      Latest with line items
GET    /api/v1/deals/:dealId/operating-statement/noi-summary NOI card data
GET    /api/v1/deals/:dealId/operating-statement/:osId       Specific statement
POST   /api/v1/deals/:dealId/operating-statement             Create header
```

**NOI Summary response:**
```json
{
  "os_id": "...",
  "period": "2024-01 – 2024-12",
  "budget_type": "Actuals",
  "effective_gross_income": 679600,
  "total_expenses": 319600,
  "noi": 360000,
  "expense_ratio": 47.0
}
```

---

## Connect to Frontend (Just-deal)

1. Copy `frontend-integration/api.js` → `src/services/api.js` in your frontend

2. Add to frontend `.env.local`:
```env
# Next.js
NEXT_PUBLIC_API_URL=http://localhost:3001/api/v1

# Vite
VITE_API_URL=http://localhost:3001/api/v1
```

3. Use in components:
```js
import { dealsApi, rentRollApi, operatingStatementApi } from '@/services/api';

// Deals table
const { data: deals, meta } = await dealsApi.list({ page: 1, limit: 25 });

// Deal workspace
const deal = await dealsApi.get(dealId);

// Rent roll tab
const { data: units, meta } = await rentRollApi.units(dealId, { page: 1 });

// NOI card
const noi = await operatingStatementApi.noi(dealId);
```

---

## Seeded Data (after running seed.js)

| Table                          | Rows |
|--------------------------------|------|
| organizations                  | 1    |
| users                          | 2    |
| org_memberships                | 2    |
| deals                          | 8    |
| properties                     | 8    |
| rent_rolls                     | 1    |
| rent_roll_units                | 15   |
| operating_statements           | 1    |
| operating_statement_line_items | 13   |

**Test Deal IDs:**
```
10000000-0000-0000-0000-000000000001  → 9730 Whitehurst Dr       (New,      52 units)
10000000-0000-0000-0000-000000000002  → Sunset Ridge Apartments   (Active,  120 units)
10000000-0000-0000-0000-000000000003  → The Meridian at Oak Lawn  (Bid Placed, 210 units)
10000000-0000-0000-0000-000000000004  → Lakewood Commons          (Dormant,  88 units)
10000000-0000-0000-0000-000000000005  → Plano Tech Corridor Apts  (Active,  168 units)
10000000-0000-0000-0000-000000000006  → Austin East Riverside     (Closed,  144 units)
10000000-0000-0000-0000-000000000007  → Houston Galleria Flats    (Passed,   96 units)
10000000-0000-0000-0000-000000000008  → The Grove at Frisco ⭐    (Active,  312 units)
```

---

## Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `Can't reach database server` | Check DATABASE_URL in .env — verify Supabase password |
| `@prisma/client not found` | Run `npx prisma generate` |
| `Table does not exist` | Run `npx prisma db push` |
| `CORS error in browser` | Add your frontend port to ALLOWED_ORIGINS in .env |
| `Port 3001 in use` | Change PORT=3002 in .env |
| `Cannot find module 'bcryptjs'` | Run `npm install` |

---

## Useful Commands

```bash
npm run dev          # Start with hot reload
npm start            # Start production
node src/database/seed.js   # Re-seed data
npx prisma studio    # Browse DB in browser (localhost:5555)
npx prisma db push   # Push schema changes to Supabase
npx prisma generate  # Regenerate Prisma client
```
